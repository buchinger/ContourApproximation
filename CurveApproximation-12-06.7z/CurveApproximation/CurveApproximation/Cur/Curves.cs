﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MOG{

    public enum CurveType { None = -1, Hermite = 0, Bezier = 1, BSpline = 2, NURBS = 3 };


    public class Curve{
        
        /// <summary>
        /// Returns the name of the given curve
        /// </summary>
        /// <param name="ct">The curve type</param>
        /// <returns>A string representing the curve name</returns>
        public static string getName(CurveType ct){
            switch(ct){
                case CurveType.Hermite: return "Hermite";
                case CurveType.Bezier:  return "Bèzier";
                case CurveType.BSpline: return "BSpline";
                case CurveType.NURBS:   return "NURBS";
            }
            return "-";
        }



        /// <summary>
        /// This method return the curve type associated with an id
        /// </summary>
        /// <param name="id"> An integer representing the curve type. </param>
        /// <returns> The curve type. </returns>
        public static CurveType getCurveType(int id){
            switch( id ){
                case 0: return CurveType.Hermite;
                case 1: return CurveType.Bezier;
                case 2: return CurveType.BSpline;
                case 3: return CurveType.NURBS;
            }
            return CurveType.None;
        }



        public static void compareFirstDerivative(Curves.ICurve c1, Curves.ICurve c2) {
            double delta = 0.0000000001;
            double begin = 0;
            double end = 1;
            Console.Write("First Derivative c1: "); 
            Vec3 res = (c1.getPointAt(end) - c1.getPointAt(end-delta)) / delta;
            Console.WriteLine("x="+res.x+"  /  y="+res.y);
            Console.Write("First Derivative c2: ");
            res = (c2.getPointAt(begin+delta) - c2.getPointAt(begin)) / delta;
            Console.WriteLine("x=" + res.x + "  /  y=" + res.y);
            Console.WriteLine("-----------------------");
        }



        public static void compareSecondDerivative(Curves.ICurve c1, Curves.ICurve c2) {
            double delta  = 0.000001;
            double begin  = 0.00001;
            double end    = 0.99999;
            Console.Write("Second Derivative c1: "); 
            Vec3 endPt = c1.getPointAt(end);
            Vec3 res = ((c1.getPointAt(end+delta) - endPt) / delta  -  (endPt - c1.getPointAt(end-delta)) / delta) / delta;
            Console.WriteLine("x="+res.x+"  /  y="+res.y);
            Console.Write("Second Derivative c2: ");
            Vec3 begPt = c2.getPointAt(begin);
            res = ((c2.getPointAt(begin+delta) - begPt) / delta  -  (begPt - c2.getPointAt(begin-delta)) / delta) / delta;
            Console.WriteLine("x=" + res.x + "  /  y=" + res.y);
            Console.WriteLine("-----------------------");
        }
        


        /// <summary>
        /// prevent instantiation of objects
        /// </summary>
        private Curve() { }

    }


}
