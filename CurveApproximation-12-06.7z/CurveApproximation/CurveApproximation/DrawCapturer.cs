﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace CurveApproximation {

    public partial class DrawCapturer : Form {

        GraphicsPath draft;
        Point lastPoint = new Point();
        bool isDrawing = false;


        //=======================================================================
        public DrawCapturer() {
            InitializeComponent();
            this.KeyPreview = true;
        }
        //=======================================================================



        //=======================================================================
        private void startDrawing(object sender, MouseEventArgs e) {
            if( draft == null )
                draft = new GraphicsPath();
            else
                draft.Reset();
            lastPoint = new Point(e.X, e.Y);
            isDrawing = true;
        }
        //=======================================================================
        private void stopDrawing(object sender, MouseEventArgs e) {
            isDrawing = false;
            drawPanel.Invalidate();
        }
        //=======================================================================
        private void mouseMove(object sender, MouseEventArgs e) {
            if (isDrawing) {
                draft.AddLine(lastPoint.X, lastPoint.Y, e.X, e.Y);
                lastPoint.X = e.X;
                lastPoint.Y = e.Y;
            }
        }
        //=======================================================================



        //=======================================================================
        /// <summary>
        /// Called when the drawPanel needs to be (re)draw
        /// </summary>
        private void repaint(object sender, PaintEventArgs e) {
            Pen pen = new Pen(Color.Black, 1);
            if( draft == null || draft.PointCount == 0 ) return;
            e.Graphics.DrawPath( pen, draft );

            /* Draw each pixel at a time
            Pen pencil = new Pen(Color.Red, 1);
            PointF[] points = draft.PathPoints;
            for( int i = 0 ; i < points.Length-1 ; i++ ) {
                Point p1 = new Point( (int) points[i].X, (int) points[i].Y );
                Point p2 = new Point( (int) points[i+1].X, (int) points[i+1].Y );
                
                foreach(Point p in list)
                    e.Graphics.DrawRectangle( pencil, p.X, p.Y, 1, 1 );
            }    
            */
        }
        //=======================================================================




        //=======================================================================
        /// <summary>
        /// Called when the return button is pressed
        /// </summary>
        private void OnPressedReturn(object sender, EventArgs e) {
            Program.DrawToMainWindow();
        }
        //=======================================================================





        //=======================================================================
        /// <summary>
        /// Called when the save button is pressed
        /// </summary>
        private void OnPressedSave(object sender, EventArgs e) {
            if( draft == null || draft.PointCount == 0 ) return;

            // Configure save file dialog box
            System.Windows.Forms.SaveFileDialog dialog = new System.Windows.Forms.SaveFileDialog();
            dialog.FileName = "PointCloud2D";   // Default file name
            dialog.DefaultExt = ".txt";         // Default file extension
            dialog.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            // Show save file dialog box and Process save file dialog box results if ok is pressed
            if( dialog.ShowDialog()  == DialogResult.OK) {
                System.IO.StreamWriter file = new System.IO.StreamWriter( dialog.FileName );
                Point last = new Point( -1, -1 );
                PointF[] points = draft.PathPoints;

                for( int i = 0 ; i < points.Length - 1 ; i++ ) {
                    Point p1 = new Point( (int) points[i].X, (int) points[i].Y );
                    Point p2 = new Point( (int) points[i + 1].X, (int) points[i + 1].Y );
                    List<Point> list = Toolbox.GetPointsInSegment( p1, p2 );
                    
                    foreach( Point p in list ) {
                        if( !(p.X == last.X && p.Y == last.Y)  )
                            file.WriteLine( p.X + " " + p.Y );
                        last = p;
                    }

                }
                file.Close();
            }
        }
        //=======================================================================


        //=======================================================================




        //=======================================================================
        private void onFormClosed( object sender, FormClosedEventArgs e ) {
            Program.DrawToMainWindow( false );
        }
        //=======================================================================




        //=======================================================================
        private void OnGenerateClick(object sender, EventArgs e) {
            List<Point> pixels = new List<Point>();
            Point point = new Point(0,0);
            int minX, minY;
            minX = minY = int.MaxValue;

            pixels.Add( point );
            foreach (char c in textDraw.Text) {
                if (c < '0' || c > '9') continue;
                switch( c ) {
                    case '0': point.X += 1; break;
                    case '1': point.X += 1; point.Y -= 1; break;
                    case '2': point.Y -= 1; break;
                    case '3': point.Y -= 1; point.X -= 1; break;
                    case '4': point.X -= 1; break;
                    case '5': point.X -= 1; point.Y += 1; break;
                    case '6': point.Y += 1; break;
                    case '7': point.Y += 1; point.X += 1; break;
                }
                pixels.Add( point );
                if( point.X < minX ) minX = point.X;
                if (point.Y < minY ) minY = point.Y;
            }

            const int offset = 50;
            if (draft == null) draft = new GraphicsPath();
            else draft.Reset();
            minX = -minX;
            minY = -minY;
            foreach (Point p in pixels) {
                point = p;
                point.X += minX + offset;
                point.Y += minY + offset;
                draft.AddLine( point, point );
            }

            drawPanel.Invalidate();
        }
        //=======================================================================



        //=======================================================================
        private void OnLoadClick(object sender, EventArgs e) {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Filter = "Image Files|*.jpg;*.png";  // Filter files by extension
            fileDialog.Multiselect = false;
            if( fileDialog.ShowDialog() == DialogResult.OK ) {
                try {
                    loadImage( fileDialog.FileName );
                } catch(Exception ex) {
                    MessageBox.Show( "The file could not be opened or parsed!\n"+ex.Message, "Error in Loading File", MessageBoxButtons.OK, MessageBoxIcon.Error );
                }
            }
        }
        //=======================================================================



        private void loadImage(string filename) {
            Bitmap image = new Bitmap( filename );
            int column = -1, row = -1;
            for (int y = 0; y < image.Height && row == -1; y++)
                for (int x = 0; x < image.Width; x++)
                    if (image.GetPixel( x, y ).GetBrightness() < 0.8f) {
                        column = x;
                        row = y;
                        break;
                    }

            Point finish = new Point( column , row );
            Stack<int> path = new Stack<int>();
            bool validPath = dfsImage( image, path, row, column, finish );
            if (!validPath) {
                MessageBox.Show( "No valid path could be found in the selected image!", "Error while parsing image", MessageBoxButtons.OK, MessageBoxIcon.Error );
                return;
            }

            // fill textbox - textDraw
            string chainCode = ""; 
            int seq = 0;
            foreach(int d in path) {
                chainCode += d;
                seq++;
                if( seq>=5) {
                    seq = 0;
                    chainCode += ' ';
                }
            }
            textDraw.Text = chainCode;
        }


        private bool dfsImage( Bitmap image, Stack<int> path, int y, int x, Point finish) {
            image.SetPixel( x, y, Color.White );
            int[] xs = { 1,  1,  0, -1, -1, -1, 0, 1 };
            int[] ys = { 0, -1, -1, -1,  0,  1, 1, 1 };
            
            for(int i=0; i<xs.Length; i++) {
                if ( x + xs[i] < 0 || y + ys[i] < 0 ) continue;
                if ( x + xs[i] >= image.Width  ||  y + ys[i] >= image.Height ) continue;

                if (image.GetPixel( x + xs[i], y + ys[i] ).GetBrightness() < 0.8f) {
                    path.Push( i );
                    if (dfsImage( image, path, y + ys[i], x + xs[i], finish ))
                        return true;
                }
                else if (path.Count > 9 && x + xs[i] == finish.X && y + ys[i] == finish.Y)
                    return true;
            }

            if( path.Count>0 )
                path.Pop();
            return false;
        }
    }

}
