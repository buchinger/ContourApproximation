﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MOG.Curves {
    
    /// <summary>
    /// B-Spline is defined by several control points, knot vector and curve degree.
    /// #knots = #controlPoints + degree+1.
    /// </summary>
    public class BSpline : ICurve {
        /// <summary>
        /// Stores all deBoor coeficients (binded to the knot vector - so each BSpline has it own boor dictionary)
        /// </summary>
        private Dictionary<Vec3, double> boor_calculated = new Dictionary<Vec3, double>(new MyComparer());
        private int curve_degree;
        private int K;
        private List<Vec3> control_points;
        private List<double> knot_values;
        private Dictionary<double, Vec3> curve_points = new Dictionary<double, Vec3>();




        /// <summary>
        /// Required for the SortedDictionary used for Dynamic Programmin
        /// </summary>
        private class MyComparer : IEqualityComparer<Vec3> {
            public bool Equals(Vec3 a, Vec3 b) {
                return a.x == b.x && a.y == b.y && a.z == b.z;
            }
            public int GetHashCode(Vec3 obj) {
                return ("" + obj.x + "-" + obj.y + "-" + obj.z).GetHashCode();
            }
        }





        /// <summary>
        /// Initialize a BSpline curve with a knot vector, curve degree and list of control points
        /// </summary>
        /// <param name="knots">The list of knot values (knot vector)</param>
        /// <param name="degree">The curve degree</param>
        /// <param name="cps">The list of control points.</param>
        public BSpline(List<double> knots, int degree, List<Vec3> cps) {
            K = degree + 1;
            if (knots.Count != cps.Count + K) throw new ArgumentException();
            knot_values = new List<double>(knots);
            curve_degree = degree;
            control_points = new List<Vec3>(cps);
        }



        /// <summary>
        /// Initialize a BSpline curve with a knot vector, curve degree and list of control points
        /// </summary>
        /// <param name="knots">The list of knot values (knot vector)</param>
        /// <param name="degree">The curve degree</param>
        /// <param name="cps">The list of control points.</param>
        public BSpline(List<double> knots, int degree, List<Point<int>> points) {
            K = degree + 1;
            if (knots.Count != points.Count + K) throw new ArgumentException();
            knot_values = new List<double>(knots);
            curve_degree = degree;
            control_points = new List<Vec3>();
            foreach (Point<int> p in points)
                control_points.Add(new Vec3(p.x, p.y, 0));
        }





        /// <summary>
        /// Calculates the Blend Function using Cox de Boor
        /// </summary>
        /// <param name="i"></param>
        /// <param name="k"></param>
        /// <param name="t"></param>
        /// <param name="knot_vector"></param>
        /// <returns></returns>
        public double coxDeBoor(int i, int k, double t) {
            // Console.WriteLine("deBoorsRecursion: " + i + " " + k + " " + t);
            if (k == 1) {
                if (knot_values[i + 1] >= 1) {
                    if (t <= knot_values[i + 1] + Double.Epsilon && t >= knot_values[i]) return 1;
                    else return 0;
                }
                else {
                    if (t < knot_values[i + 1] && t >= knot_values[i] - Double.Epsilon) return 1;
                    else return 0;
                }
            }

            Vec3 param = new Vec3(i, k, t);
            if (boor_calculated.ContainsKey(param)) { // Dynamic Programing o//
                return boor_calculated[param];
            }

            double boors = 0;
            // Console.WriteLine("Boors accessing indexes: " + (i + k) + " / "+knot_vector.Count);
            double denominator = (knot_values[i + k - 1] - knot_values[i]);
            if (denominator > 0)
                boors = ((t - knot_values[i]) / denominator) * coxDeBoor(i, k - 1, t);
            denominator = (knot_values[i + k] - knot_values[i + 1]);
            if (denominator > 0)
                boors += ((knot_values[i + k] - t) / denominator) * coxDeBoor(i + 1, k - 1, t);

            boor_calculated.Add(param, boors);
            return boors;
        }



        /// <summary>
        /// Returns the points of this curve at a given parameter between [0,1]
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public Vec3 getPointAt(double t) {
            // First check if the curve point was already calculated
            if (curve_points.ContainsKey(t))
                return curve_points[t];

            // If the curve point was not already calculated, we calculate it and store the result for future use
            int n = control_points.Count;
            int k = curve_degree + 1;
            Vec3 res = new Vec3();
            double boors;
            double boors_sum = 0;

            for (int i = 0; i < n; i++) {
                Vec3 param = new Vec3(i, k, t);
                if( boor_calculated.ContainsKey(param) ) { // Dynamic Programing =)
                    boors = boor_calculated[param];
                }
                else {
                    boors = coxDeBoor(i, k, t);
                    //Console.WriteLine("DeBoor: " + i + " " + k + " " + t + " => " + boors);
                }

                boors_sum += boors;
                res = res + (control_points[i] * boors);
            }

            // If the boors_sum is not 1 (or almost one) the value of parameter t cannot be used
            if (boors_sum < 0.999)
                res.assign(-1, -1, -1);

            //Console.WriteLine("res(" + t + ") = " + res.x + " - " + res.y + " -> Boorsum: "+boors_sum);
            curve_points.Add(t, res);
            return res;
        }





        //==========================================================================
        //==========================================================================
        //==========================================================================
        private Vec3 getDerivativePoint(int index) {
            Vec3 res = (control_points[index + 1] - control_points[index]) * (curve_degree / (knot_values[index + curve_degree + 1] - knot_values[index + 1]));
            return res;
        }

        


        public Vec3 getFirstDerivative(int u) {
            Vec3 res = new Vec3(0, 0, 0);
            if (u == 0) {
                res = getDerivativePoint( 0 );
            }
            else if (u == 1) {
                int n = control_points.Count() - 1;
                res = getDerivativePoint( n-1 );
            }
            return res;
            /* could be used for letting the function to be generic (but add complexity + comp. time)
            List<double> nos = new List<double>(knot_values);
            nos.RemoveAt( knot_values.Count-1 ); nos.RemoveAt(0);
            List< Point<int> > pontos = new List<Point<int>>();
            for(int i=0; i<control_points.Count()-1; i++){
                Vec3 aux = getDerivativePoint( i );
                pontos.Add( new Point<int>( (int) aux.x, (int) aux.y ) );
            }
            BSpline teste = new BSpline( nos, curve_degree-1, pontos );
            Vec3 r = teste.getPointAt(1);
            */
        }


        

        public Vec3 getSecondDerivative(int u) {
            Vec3 res = new Vec3(0, 0, 0);
            if (u == 0) {
                int p1 = curve_degree + 1;
                int p2 = curve_degree + 2;
                res = (control_points[0] / knot_values[p1]);
                res = res - (control_points[1] * (knot_values[p1] + knot_values[p2])) / (knot_values[p1] * knot_values[p2]);
                res = res + (control_points[2] / knot_values[p2]);
                res = res * (curve_degree * (curve_degree - 1)) / knot_values[p1];
            }
            else if (u == 1) {
                int n = control_points.Count() - 1;
                int m = knot_values.Count() - 1;
                int mp1 = m-curve_degree-1;
                int mp2 = mp1-1;
                res = control_points[n] / (1 - knot_values[mp1]);
                res = res - (control_points[n-1] * (2-knot_values[mp1]-knot_values[mp2]) / ((1-knot_values[mp1])*(1-knot_values[mp2])));
                res = res + (control_points[n-2] / (1-knot_values[mp2]));
                res = res * (curve_degree * (curve_degree - 1)) / (1 - knot_values[mp1]);
            }
            return res;

            /* could be used for letting the function to be generic (but add complexity + comp. time)
            List<double> nos = new List<double>(knot_values);
            nos.RemoveAt(knot_values.Count - 1); nos.RemoveAt(0);
            List<Point<int>> pontos = new List<Point<int>>();
            for (int i = 0; i < control_points.Count() - 1; i++) {
                Vec3 aux = getDerivativePoint(i);
                pontos.Add(new Point<int>((int)aux.x, (int)aux.y));
            }
            BSpline teste = new BSpline(nos, curve_degree - 1, pontos);

            List<double> nos2 = new List<double>(teste.knot_values);
            nos2.RemoveAt(teste.knot_values.Count - 1); nos2.RemoveAt(0);
            List<Point<int>> pontos2 = new List<Point<int>>();
            for (int i = 0; i < teste.control_points.Count() - 1; i++) {
                Vec3 aux = teste.getDerivativePoint(i);
                pontos2.Add(new Point<int>((int)aux.x, (int)aux.y));
            }
            BSpline teste2 = new BSpline(nos2, curve_degree - 2, pontos2);           
            Vec3 r = teste2.getPointAt(1);
            */
        }

        

        public void adjustC1( Vec3 tangent ){
            double d = (curve_degree / knot_values[curve_degree + 1]);
            Vec3 aux = control_points[0] * d;
            aux = (tangent + aux) / d;
            moveControlPoint( 1 , (int) aux.x , (int) aux.y );
        }


        public void adjustC2( Vec3 acceleration ) {
            double kp1 = knot_values[curve_degree + 1];
            double kp2 = knot_values[curve_degree + 2];
            double alfa = curve_degree * (curve_degree - 1) / kp2;
            double beta = alfa / kp2;  // this multiplies the P2 point
            Vec3 q0 = control_points[0] * alfa / kp1;
            Vec3 q1 = control_points[1] * (kp1 + kp2) * alfa / (kp1 * kp2);
            Vec3 res = (acceleration - q0 + q1) / beta;
            moveControlPoint(2, (int)res.x, (int)res.y);

            /* For checking if the answer is matching with the given accelaration
            Vec3 p0 = getDerivativePoint(0);
            Vec3 p1 = getDerivativePoint(1);
            Vec3 teste = (p1 - p0) * (degree / knot_values[degree + 2]);
            return;
            */
        }
        //==========================================================================
        //==========================================================================
        //==========================================================================





        public int getSize() {
            return control_points.Count();
        }



        /// <summary>
        /// Returns the coordinates of a given control point
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Vec3 getControlPoint(int index) {
            if (index < 0 || index >= control_points.Count()) return new Vec3(-1, -1, -1);
            return control_points[index];
        }


        /// <summary>
        /// Return the list of control points from this bezier curve.
        /// </summary>
        /// <returns></returns>
        public List<Vec3> getControlPoints() {
            List<Vec3> list = new List<Vec3>(control_points);
            return list;
        }



        public int hasControlPointIn(int x, int y, int z = 0) {
            for (int i = 0; i < control_points.Count(); i++)
                if (Math.Abs(x - control_points[i].x) <= 2 && Math.Abs(y - control_points[i].y) <= 2)
                    return i;
            return -1;
        }



        public void moveControlPoint(int index, int x, int y) {
            control_points[index].x = x;
            control_points[index].y = y;
            curve_points.Clear();
        }




        public void translate(int x, int y) {
            foreach (Vec3 p in control_points) {
                p.x += x;
                p.y += y;
            }
            curve_points.Clear();
        }

    }
}
