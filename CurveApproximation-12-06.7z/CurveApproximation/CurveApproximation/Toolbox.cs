﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurveApproximation{
    class Toolbox {
        static Random rand = new Random();
        private static int rand_iterations = 0;
        private const int MAX_RAND_ITERATIONS = 500;


        //==============================================================
        /// <summary> Returns an integer between a given minimum and maximum value </summary>
        /// <param name="min"> The minimum possible value. </param>
        /// <param name="max"> The maximum possible value.</param>
        public static int GetRandomInt(int min, int max) {
            if( rand_iterations > MAX_RAND_ITERATIONS) {
                rand_iterations = 0;
                rand = new Random();
            }
            rand_iterations++;
            return rand.Next( min, max+1 ); //next generate a number between [min, max)
        }
        //==============================================================



        //==============================================================
        /// <summary>
        /// Receives a full path to a file and returns just the filename,
        /// without the directories names
        /// </summary>
        public static string GetFileName( string path ) {
            char[] separators = { '\\', '/' };
            string[] pieces = path.Split( separators );
            return pieces[ pieces.Length-1 ];
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Convert a pointF to a point (rounding the values)
        /// </summary>
        public static void PointFtoPoint( ref Point point, PointF pointf ) {
            point.X = Convert.ToInt32( Math.Round( pointf.X ) );
            point.Y = Convert.ToInt32( Math.Round( pointf.Y ) );
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Creates a list of Pixels that compose a line segment based on
        /// two pixels that represents the end points of this segment.
        /// </summary>
        /// <param name="a"> The beggining of the segment. </param>
        /// <param name="b"> The end of the segment. </param>
        /// <returns> A HashSet of pixels that compose the line segment. </returns>
        public static List<Point> GetPointsInSegment( Point a, Point b ) {
            List<Point> pixels = new List<Point>();
            float deltaX = b.X - a.X;
            float deltaY = b.Y - a.Y;
            if (Math.Abs( deltaX ) < 0.1f && Math.Abs( deltaY ) < 0.1f) {
                pixels.Add( new Point( a.X, a.Y ) );
            }
            else if ( Math.Abs(deltaX) >= Math.Abs(deltaY) ) {
                deltaY = deltaY / Math.Abs(deltaX);
                float y = a.Y;
                if ( deltaX > 0 )
                    for( int x = a.X ; x <= b.X ; x++, y += deltaY )
                        pixels.Add( new Point( x, Convert.ToInt32( Math.Round( y ) ) ) );
                else
                    for (int x=a.X; x>=b.X; x--, y+=deltaY)
                        pixels.Add( new Point( x, Convert.ToInt32( Math.Round( y ) ) ) );
            }
            else {
                deltaX = deltaX / Math.Abs(deltaY);
                float x = a.X;
                if( deltaY > 0 )
                    for (int y=a.Y; y<=b.Y; y++, x+=deltaX)
                        pixels.Add( new Point( Convert.ToInt32( Math.Round( x ) ), y ) );
                else
                    for (int y=a.Y; y>=b.Y; y--, x+=deltaX)
                        pixels.Add( new Point( Convert.ToInt32( Math.Round( x ) ), y ) );
            }
            /* This code checks inconsistencies
            for (int i = 1; i < pixels.Count; i++)
                if (Math.Abs( pixels[i].X - pixels[i - 1].X ) > 1.1 || Math.Abs( pixels[i].Y - pixels[i - 1].Y ) > 1.1)
                    Console.WriteLine( "Something is very wrong" );
            */
            return pixels;
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Computes the squared euclidean distance between pixel pa and pixel pb
        /// </summary>
        public static int distance( Point pa, Point pb ) {
            int px = (pa.X - pb.X);
            int py = (pa.Y - pb.Y);
            return px*px + py*py;
            //return Math.Sqrt( px * px + py * py );
        }
        //==============================================================


        //==============================================================
        /// <summary>
        /// Computes the squared euclidean distance between pixel pa and pixel pb
        /// </summary>
        public static double distance(PointF pa, PointF pb) {
            double px = (pa.X - pb.X);
            double py = (pa.Y - pb.Y);
            return px * px + py * py;
            //return Math.Sqrt( px * px + py * py );
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Computes the minimum distance between two lists of pixels.
        /// Output the minimum distances in parameters distA and distB.
        /// </summary>
        /// <param name="listA"> The first list of points. </param>
        /// <param name="listB"> The second list of points. </param>
        /// <param name="distA"> A vector of double where the minimum distances for list A will be stored. </param>
        /// <param name="distB"> A vector of double where the minimum distances for list B will be stored. </param>
        public static void ComputeMinDistance( List<Point> listA, HashSet<Point> listB,
                                           out int[] distA, out int[] distB ) {
            // initialization
            distA = new int[ listA.Count ];
            distB = new int[ listB.Count ];

            int i,j;
            for (i = 0; i < listA.Count; i++)
                distA[i] = int.MaxValue;
            for (j = 0; j < listB.Count; j++)
                distB[j] = int.MaxValue;

            // compute minimum distances
            i = 0;
            foreach(Point a in listA) {
                j = 0;
                foreach(Point b in listB ) {
                    int dist = distance( a , b );
                    if (dist < distA[i])
                        distA[i] = dist;
                    if (dist < distB[j])
                        distB[j] = dist;
                    j++;
                }
                i++;
            }
        }
        //==============================================================



        //==============================================================
        /// <summary>
        /// Computes the Integral Squared Error. It is approximated with the sum of the minimum
        /// distances between each point of listB to listA.
        /// </summary>
        /// <param name="listA"> A list of Point with all points in the objetive. </param>
        /// <param name="listB"> A list of PointF with all sample points in a given curve. </param>
        /// <param name="listB"> (output) The maximal error found in the list. </param>
        /// <returns> Returns the sum of the minimum integral squared error. </returns>
        public static double ComputeISE(List<Point> listA, HashSet<PointF> listB, ref double maxE ) {
            double res = 0;
            if( listA.Count > 0 )
                maxE = Double.MinValue;

            foreach (Point a in listA) {
                double dist = double.MaxValue;
                foreach (PointF b in listB) {
                    double d = distance( a, b );
                    if (d < dist)
                        dist = d;
                }
                res += dist;
                if (dist > maxE && dist < double.MaxValue) 
                    maxE = dist; //updates the maximal error
            }
            return res;
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Generate a List containing n elements randomly choosen from a given list.
        /// </summary>
        /// <param name="list"> The list of itens where to choose from. </param>
        /// <param name="n"> The number of elements that should be choosen. </param>
        /// <returns></returns>
        public static List<Point> GetNRandomElements( List<Point> list, int n ) {
            List<Point> res;

            // If it is easier to insert n entries than remove (m-n) entries
            if ( n <= list.Count / 2 ) {
                res = new List<Point>();
                List<Point> aux = new List<Point>( list );
                for (int i=0; i<n; i++) {
                    int index = rand.Next( 0, aux.Count );
                    res.Add( aux[index] );
                    aux.RemoveAt( index );
                }
            }
            // Else, if it is easier to remove (m-n) entries than insert n entries
            else {
                res = new List<Point>( list );
                while( res.Count < n ){
                    int index = rand.Next( 0, res.Count );
                    res.RemoveAt( index );
                }
            }
            return res;
        }
        //==============================================================



        //==============================================================
        /// <summary>
        /// Apply a Deepth-First-Search in a list of pixels in order to find its extremity
        /// </summary>
        /// <param name="pixels"> The list of pixels. </param>
        /// <param name="init"> The index of the initial pixel (from where to start). </param>
        /// <returns> The last pixel visited or null if the init index is invalid. </returns>
        /*public static Pixel DFS( List<Pixel> pixels, int init ) {
            if( init >= pixels.Count ) return null;

            // Find the max x,y and min x,y
            int xMax, xMin, yMax, yMin;
            xMax = yMax = int.MinValue;
            xMin = yMin = int.MaxValue;
            for (int i = 0; i < pixels.Count; i++) {
                if (xMax < pixels[i].x)
                    xMax = pixels[i].x;
                if (xMin > pixels[i].x)
                    xMin = pixels[i].x;
                if (yMax < pixels[i].y)
                    yMax = pixels[i].y;
                if (yMin > pixels[i].y)
                    yMin = pixels[i].y;
            }

            // Creates a vizited matrix
            int deltaX = xMax - xMin + 1 + 2; // create an extra espace in X
            int deltaY = yMax - yMin + 1 + 2; // create an extra espace in Y
            bool[][] vizited = new bool[deltaX][];
            for (int i = 0; i < deltaX; i++)
                vizited[i] = new bool[deltaY];

            // fill all positions as non vizited
            for (int i = 0; i < deltaX; i++)
                for (int j = 0; j < deltaY; j++)
                    vizited[i][j] = false;

            // mark all pixels from the list as true
            xMin -= 1;
            yMin -= 1;
            for (int i = 0; i < pixels.Count; i++)
                vizited[ pixels[i].x - xMin ][ pixels[i].y - yMin ] = true;

            Pixel next = new Pixel( pixels[init].x - xMin, pixels[init].y - yMin );
            for( ; ; ) {
                vizited[ next.x ][ next.y ] = false; // mark the current pixel as vizited = false
                if (vizited[next.x][next.y-1]) // tries to go up
                    next.y -= 1;
                else if (vizited[next.x+1][next.y-1]){ // tries to go northeast
                    next.y -= 1;
                    next.x += 1;
                }
                else if (vizited[next.x + 1][next.y]) // tries to go east
                    next.x += 1;
                else if (vizited[next.x + 1][next.y + 1]) { // tries to go southeast
                    next.y += 1;
                    next.x += 1;
                }
                else if (vizited[next.x][next.y + 1]) // tries to go south
                    next.y += 1;
                else if (vizited[next.x - 1][next.y - 1]) { // tries to go southwest
                    next.y += 1;
                    next.x -= 1;
                }
                else if (vizited[next.x - 1][next.y]) // tries to go west
                    next.x -= 1;
                else if (vizited[next.x - 1][next.y - 1]) { // tries to go northwest
                    next.y -= 1;
                    next.x -= 1;
                }
                
                if( !vizited[next.x][next.y] ) //if next has not moved then it is the last point
                    break;
            }

            next.x += xMin;
            next.y += yMin;
            return next;
        }
        */
        //==============================================================

    }
}
