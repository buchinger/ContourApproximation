﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace CurveApproximation{

    enum FittingType { None, OrderedPoints, NonOrderedPoints }; 

    static class Program{
        
        public static int CurveSamples = 15; // number of curve samples between control points
        public static FittingType Operation = FittingType.None;
        public static GraphicsPath DraftOriginal;
        public static GraphicsPath DraftApproximation;
        public static List<Point> ControlPoints;
        public static GraphicsPath DraftRandomSolution;
        public static List<Point> RandomControlPoints;

        public static double BestFitness;
        public static double BestMSD;
        public static double BestMaximalError;
        public static int CurrentGeneration;
        public static int CurrentPopulationSize;
        public static double CurrentDiversity;
        

        static MainMenu mainMenuForm;
        static Solver solverForm;
        static DrawCapturer drawForm;
        
        public static bool StopEvolution = false;
        public static bool EvolutionReady = false;


        //============================================================
        /// <summary>
        /// Starts the application
        /// </summary>
        [STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            mainMenuForm = new MainMenu();
            Application.Run( mainMenuForm );
        }
        //============================================================
        public static void MainToDrawWindow() {
            mainMenuForm.Hide();
            drawForm = new DrawCapturer();
            drawForm.Show();
        }
        //============================================================
        public static void DrawToMainWindow(bool close=true) {
            if( close ) drawForm.Close();
            mainMenuForm.Show();
        }
        //============================================================
        public static void MainToSolverWindow() {
            mainMenuForm.Hide();
            solverForm = new Solver();
            solverForm.Show();
        }
        //============================================================
        public static void SolverToMainWindow(bool close=true) {
            if( close ) solverForm.Close();
            mainMenuForm.Show();
        }
        //============================================================




        //============================================================
        /// <summary>
        /// Updates the best solution 
        /// </summary>
        /// <param name="solution"> A solution object containing the solution list of pixels and its fitness. </param>
        public static void ChangeBestSolution( Heuristics.Solution solution ) {
            if( DraftApproximation != null )
                DraftApproximation.Reset();
            else
                DraftApproximation = new GraphicsPath();
            if( ControlPoints != null )
                ControlPoints.Clear();
            else
                ControlPoints = new List<Point>();

            foreach( Point pt in solution.Pixels )
                DraftApproximation.AddLine( pt, pt );
            Point point = new Point();
            foreach( PointF ptf in solution.Curve.getControlPoints()){
                point.X = Convert.ToInt32( Math.Round( ptf.X ) );
                point.Y = Convert.ToInt32( Math.Round( ptf.Y ) );
                ControlPoints.Add( point );
            }
                
            BestFitness = solution.Fitness;
            BestMSD = solution.MSD;
            BestMaximalError = solution.MaxE;
            solverForm.bestSolutionUpdated();
        }
        //============================================================


        


        //============================================================
        /// <summary>
        /// Updates the generation in the main window
        /// </summary>
        /// <param name="generation"> The current generation </param>
        public static void ChangeGeneration( int generation, int populationSize, double diversity, Heuristics.Solution randSolution ) {
            CurrentGeneration = generation;
            CurrentPopulationSize = populationSize;
            CurrentDiversity = diversity;
            
            if( generation % 5 == 0 ) {
                if (DraftRandomSolution == null) DraftRandomSolution = new GraphicsPath();
                else DraftRandomSolution.Reset();
                foreach (Point pt in randSolution.Pixels)
                    DraftRandomSolution.AddLine( pt, pt );

                if (RandomControlPoints == null) RandomControlPoints = new List<Point>();
                else RandomControlPoints.Clear();
                Point point = new Point();
                foreach(PointF ptf in randSolution.Curve.getControlPoints()) {
                    point.X = Convert.ToInt32( Math.Round( ptf.X ) );
                    point.Y = Convert.ToInt32( Math.Round( ptf.Y ) );
                    RandomControlPoints.Add( point );
                }
            }
            solverForm.generationChanged();
        }
        //============================================================





        //============================================================
        /// <summary>
        /// Called by the external thread that are executing the evolution
        /// and receives the message for stopping
        /// </summary>
        public static void EvolutionStoped() {
            solverForm.evolutionStoped();
        }
        //============================================================





        //============================================================
        /// <summary>
        /// Called when a evolution process is stopped and the main
        /// Variables must be reset to their default values
        /// </summary>
        public static void ResetProgramValues() {
            Program.BestFitness = -1;
            Program.BestMaximalError = -1;
            Program.BestMSD = -1;
            Program.CurrentGeneration = -1;
            Program.CurrentPopulationSize = -1;
            Program.StopEvolution = false;
            Program.EvolutionReady = true;
        }
        //============================================================




        //============================================================
        /// <summary>
        /// Reset the drafts used in the solver
        /// </summary>
        public static void resetDrafts() {
            if (Program.DraftOriginal == null)
                Program.DraftOriginal = new System.Drawing.Drawing2D.GraphicsPath();
            else
                Program.DraftOriginal.Reset();

            if (Program.DraftApproximation == null)
                Program.DraftApproximation = new System.Drawing.Drawing2D.GraphicsPath();
            else
                Program.DraftApproximation.Reset();

            if (Program.ControlPoints == null)
                Program.ControlPoints = new List<Point>();
            else
                Program.ControlPoints.Clear();

            if (Program.DraftRandomSolution == null)
                Program.DraftRandomSolution = new System.Drawing.Drawing2D.GraphicsPath();
            else
                Program.DraftRandomSolution.Reset();

            if (Program.RandomControlPoints == null)
                Program.RandomControlPoints = new List<Point>();
            else
                Program.RandomControlPoints.Clear();
        }
        //============================================================

    }

}
