﻿namespace CurveApproximation {

    partial class Solver {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;



        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing){
            if (disposing && (components != null)){
                components.Dispose();
            }
            base.Dispose( disposing );
        }



        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.drawPanel = new System.Windows.Forms.Panel();
            this.controlPanel = new System.Windows.Forms.GroupBox();
            this.checkBoxAdaptive = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.nupControlPoints = new System.Windows.Forms.NumericUpDown();
            this.nupCurveDegree = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.labelPoints = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.imageFileName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.resultsPanel = new System.Windows.Forms.GroupBox();
            this.labelMaximalError = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelMSD = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelDiversity = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelPopulationSize = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelBestFitness = new System.Windows.Forms.Label();
            this.labelGenerations = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxRandomControlPoints = new System.Windows.Forms.CheckBox();
            this.checkBoxControlPoints = new System.Windows.Forms.CheckBox();
            this.checkBoxRandomDraft = new System.Windows.Forms.CheckBox();
            this.checkBoxApproximationDraft = new System.Windows.Forms.CheckBox();
            this.checkBoxOriginalDraft = new System.Windows.Forms.CheckBox();
            this.toolTipISE = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipMSD = new System.Windows.Forms.ToolTip(this.components);
            this.trackBarZoom = new System.Windows.Forms.TrackBar();
            this.label12 = new System.Windows.Forms.Label();
            this.panelDrawBackground = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.nupGenerations = new System.Windows.Forms.NumericUpDown();
            this.nupIterations = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.controlPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupControlPoints)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupCurveDegree)).BeginInit();
            this.resultsPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarZoom)).BeginInit();
            this.panelDrawBackground.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupGenerations)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupIterations)).BeginInit();
            this.SuspendLayout();
            // 
            // drawPanel
            // 
            this.drawPanel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.drawPanel.Location = new System.Drawing.Point(0, 0);
            this.drawPanel.Name = "drawPanel";
            this.drawPanel.Size = new System.Drawing.Size(769, 460);
            this.drawPanel.TabIndex = 0;
            this.drawPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.paint);
            // 
            // controlPanel
            // 
            this.controlPanel.Controls.Add(this.label14);
            this.controlPanel.Controls.Add(this.nupIterations);
            this.controlPanel.Controls.Add(this.nupGenerations);
            this.controlPanel.Controls.Add(this.label13);
            this.controlPanel.Controls.Add(this.checkBoxAdaptive);
            this.controlPanel.Controls.Add(this.label11);
            this.controlPanel.Controls.Add(this.nupControlPoints);
            this.controlPanel.Controls.Add(this.nupCurveDegree);
            this.controlPanel.Controls.Add(this.label6);
            this.controlPanel.Controls.Add(this.label5);
            this.controlPanel.Controls.Add(this.buttonStart);
            this.controlPanel.Controls.Add(this.labelPoints);
            this.controlPanel.Controls.Add(this.label2);
            this.controlPanel.Controls.Add(this.button1);
            this.controlPanel.Controls.Add(this.imageFileName);
            this.controlPanel.Controls.Add(this.label1);
            this.controlPanel.Location = new System.Drawing.Point(14, 11);
            this.controlPanel.Name = "controlPanel";
            this.controlPanel.Size = new System.Drawing.Size(766, 73);
            this.controlPanel.TabIndex = 1;
            this.controlPanel.TabStop = false;
            this.controlPanel.Text = "Control Panel";
            // 
            // checkBoxAdaptive
            // 
            this.checkBoxAdaptive.AutoSize = true;
            this.checkBoxAdaptive.Location = new System.Drawing.Point(623, 45);
            this.checkBoxAdaptive.Name = "checkBoxAdaptive";
            this.checkBoxAdaptive.Size = new System.Drawing.Size(15, 14);
            this.checkBoxAdaptive.TabIndex = 13;
            this.checkBoxAdaptive.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(603, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Adaptive?";
            // 
            // nupControlPoints
            // 
            this.nupControlPoints.Location = new System.Drawing.Point(375, 19);
            this.nupControlPoints.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.nupControlPoints.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nupControlPoints.Name = "nupControlPoints";
            this.nupControlPoints.Size = new System.Drawing.Size(44, 20);
            this.nupControlPoints.TabIndex = 11;
            this.nupControlPoints.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nupControlPoints.ValueChanged += new System.EventHandler(this.OnControlPointsChange);
            // 
            // nupCurveDegree
            // 
            this.nupCurveDegree.Location = new System.Drawing.Point(375, 44);
            this.nupCurveDegree.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.nupCurveDegree.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nupCurveDegree.Name = "nupCurveDegree";
            this.nupCurveDegree.Size = new System.Drawing.Size(44, 20);
            this.nupCurveDegree.TabIndex = 10;
            this.nupCurveDegree.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nupCurveDegree.ValueChanged += new System.EventHandler(this.OnChangeDegree);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(293, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Curve Degree:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(284, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "# Control Points:";
            // 
            // buttonStart
            // 
            this.buttonStart.BackColor = System.Drawing.Color.LightYellow;
            this.buttonStart.Enabled = false;
            this.buttonStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStart.Location = new System.Drawing.Point(685, 15);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(75, 52);
            this.buttonStart.TabIndex = 5;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = false;
            this.buttonStart.Click += new System.EventHandler(this.startButtonClick);
            // 
            // labelPoints
            // 
            this.labelPoints.AutoSize = true;
            this.labelPoints.Location = new System.Drawing.Point(97, 47);
            this.labelPoints.Name = "labelPoints";
            this.labelPoints.Size = new System.Drawing.Size(10, 13);
            this.labelPoints.TabIndex = 4;
            this.labelPoints.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "# points:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(214, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(52, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "browse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.browseButtonClick);
            // 
            // imageFileName
            // 
            this.imageFileName.AutoSize = true;
            this.imageFileName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.imageFileName.Location = new System.Drawing.Point(97, 25);
            this.imageFileName.MaximumSize = new System.Drawing.Size(150, 13);
            this.imageFileName.MinimumSize = new System.Drawing.Size(100, 13);
            this.imageFileName.Name = "imageFileName";
            this.imageFileName.Size = new System.Drawing.Size(111, 13);
            this.imageFileName.TabIndex = 1;
            this.imageFileName.Text = "-- no image selected --";
            this.imageFileName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Image:";
            // 
            // resultsPanel
            // 
            this.resultsPanel.Controls.Add(this.labelMaximalError);
            this.resultsPanel.Controls.Add(this.label10);
            this.resultsPanel.Controls.Add(this.labelMSD);
            this.resultsPanel.Controls.Add(this.label9);
            this.resultsPanel.Controls.Add(this.labelDiversity);
            this.resultsPanel.Controls.Add(this.label8);
            this.resultsPanel.Controls.Add(this.labelPopulationSize);
            this.resultsPanel.Controls.Add(this.label7);
            this.resultsPanel.Controls.Add(this.labelBestFitness);
            this.resultsPanel.Controls.Add(this.labelGenerations);
            this.resultsPanel.Controls.Add(this.label4);
            this.resultsPanel.Controls.Add(this.label3);
            this.resultsPanel.Location = new System.Drawing.Point(789, 155);
            this.resultsPanel.Name = "resultsPanel";
            this.resultsPanel.Size = new System.Drawing.Size(183, 167);
            this.resultsPanel.TabIndex = 2;
            this.resultsPanel.TabStop = false;
            this.resultsPanel.Text = "Results";
            // 
            // labelMaximalError
            // 
            this.labelMaximalError.AutoSize = true;
            this.labelMaximalError.Location = new System.Drawing.Point(105, 91);
            this.labelMaximalError.Name = "labelMaximalError";
            this.labelMaximalError.Size = new System.Drawing.Size(10, 13);
            this.labelMaximalError.TabIndex = 11;
            this.labelMaximalError.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Best Maximal Err:";
            // 
            // labelMSD
            // 
            this.labelMSD.AutoSize = true;
            this.labelMSD.Location = new System.Drawing.Point(105, 69);
            this.labelMSD.Name = "labelMSD";
            this.labelMSD.Size = new System.Drawing.Size(10, 13);
            this.labelMSD.TabIndex = 9;
            this.labelMSD.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(41, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Best MSD:";
            this.toolTipMSD.SetToolTip(this.label9, "Matrix Squared Difference");
            // 
            // labelDiversity
            // 
            this.labelDiversity.AutoSize = true;
            this.labelDiversity.Location = new System.Drawing.Point(105, 137);
            this.labelDiversity.Name = "labelDiversity";
            this.labelDiversity.Size = new System.Drawing.Size(10, 13);
            this.labelDiversity.TabIndex = 7;
            this.labelDiversity.Text = "-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(49, 137);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Diversity:";
            // 
            // labelPopulationSize
            // 
            this.labelPopulationSize.AutoSize = true;
            this.labelPopulationSize.Location = new System.Drawing.Point(105, 113);
            this.labelPopulationSize.Name = "labelPopulationSize";
            this.labelPopulationSize.Size = new System.Drawing.Size(10, 13);
            this.labelPopulationSize.TabIndex = 5;
            this.labelPopulationSize.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(41, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Pop.  Size:";
            // 
            // labelBestFitness
            // 
            this.labelBestFitness.AutoSize = true;
            this.labelBestFitness.Location = new System.Drawing.Point(105, 46);
            this.labelBestFitness.Name = "labelBestFitness";
            this.labelBestFitness.Size = new System.Drawing.Size(10, 13);
            this.labelBestFitness.TabIndex = 3;
            this.labelBestFitness.Text = "-";
            // 
            // labelGenerations
            // 
            this.labelGenerations.AutoSize = true;
            this.labelGenerations.Location = new System.Drawing.Point(105, 24);
            this.labelGenerations.Name = "labelGenerations";
            this.labelGenerations.Size = new System.Drawing.Size(10, 13);
            this.labelGenerations.TabIndex = 2;
            this.labelGenerations.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Best Fitness (ISE):";
            this.toolTipISE.SetToolTip(this.label4, "Integral Square Error");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Generation:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxRandomControlPoints);
            this.groupBox1.Controls.Add(this.checkBoxControlPoints);
            this.groupBox1.Controls.Add(this.checkBoxRandomDraft);
            this.groupBox1.Controls.Add(this.checkBoxApproximationDraft);
            this.groupBox1.Controls.Add(this.checkBoxOriginalDraft);
            this.groupBox1.Location = new System.Drawing.Point(789, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(183, 137);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "View Panel";
            // 
            // checkBoxRandomControlPoints
            // 
            this.checkBoxRandomControlPoints.AutoSize = true;
            this.checkBoxRandomControlPoints.Location = new System.Drawing.Point(14, 114);
            this.checkBoxRandomControlPoints.Name = "checkBoxRandomControlPoints";
            this.checkBoxRandomControlPoints.Size = new System.Drawing.Size(144, 17);
            this.checkBoxRandomControlPoints.TabIndex = 6;
            this.checkBoxRandomControlPoints.Text = "Rand. Sol. Control Points";
            this.checkBoxRandomControlPoints.UseVisualStyleBackColor = true;
            this.checkBoxRandomControlPoints.CheckedChanged += new System.EventHandler(this.OnRandomControlPointsViewChanged);
            // 
            // checkBoxControlPoints
            // 
            this.checkBoxControlPoints.AutoSize = true;
            this.checkBoxControlPoints.Location = new System.Drawing.Point(14, 68);
            this.checkBoxControlPoints.Name = "checkBoxControlPoints";
            this.checkBoxControlPoints.Size = new System.Drawing.Size(160, 17);
            this.checkBoxControlPoints.TabIndex = 5;
            this.checkBoxControlPoints.Text = "Approximation Control Points";
            this.checkBoxControlPoints.UseVisualStyleBackColor = true;
            this.checkBoxControlPoints.CheckedChanged += new System.EventHandler(this.OnApproximationControlPointsViewChanged);
            // 
            // checkBoxRandomDraft
            // 
            this.checkBoxRandomDraft.AutoSize = true;
            this.checkBoxRandomDraft.Location = new System.Drawing.Point(14, 91);
            this.checkBoxRandomDraft.Name = "checkBoxRandomDraft";
            this.checkBoxRandomDraft.Size = new System.Drawing.Size(133, 17);
            this.checkBoxRandomDraft.TabIndex = 4;
            this.checkBoxRandomDraft.Text = "Random Solution Draft";
            this.checkBoxRandomDraft.UseVisualStyleBackColor = true;
            this.checkBoxRandomDraft.CheckedChanged += new System.EventHandler(this.OnRandomDraftViewChanged);
            // 
            // checkBoxApproximationDraft
            // 
            this.checkBoxApproximationDraft.AutoSize = true;
            this.checkBoxApproximationDraft.Checked = true;
            this.checkBoxApproximationDraft.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxApproximationDraft.Location = new System.Drawing.Point(14, 45);
            this.checkBoxApproximationDraft.Name = "checkBoxApproximationDraft";
            this.checkBoxApproximationDraft.Size = new System.Drawing.Size(118, 17);
            this.checkBoxApproximationDraft.TabIndex = 3;
            this.checkBoxApproximationDraft.Text = "Approximation Draft";
            this.checkBoxApproximationDraft.UseVisualStyleBackColor = true;
            this.checkBoxApproximationDraft.CheckedChanged += new System.EventHandler(this.OnApproximationDraftViewChanged);
            // 
            // checkBoxOriginalDraft
            // 
            this.checkBoxOriginalDraft.AutoSize = true;
            this.checkBoxOriginalDraft.Checked = true;
            this.checkBoxOriginalDraft.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxOriginalDraft.Location = new System.Drawing.Point(14, 25);
            this.checkBoxOriginalDraft.Name = "checkBoxOriginalDraft";
            this.checkBoxOriginalDraft.Size = new System.Drawing.Size(87, 17);
            this.checkBoxOriginalDraft.TabIndex = 2;
            this.checkBoxOriginalDraft.Text = "Original Draft";
            this.checkBoxOriginalDraft.UseVisualStyleBackColor = true;
            this.checkBoxOriginalDraft.CheckedChanged += new System.EventHandler(this.OnOriginalDraftViewChanged);
            // 
            // toolTipISE
            // 
            this.toolTipISE.ToolTipTitle = "Fitness - ISE";
            // 
            // toolTipMSD
            // 
            this.toolTipMSD.ToolTipTitle = "MSD";
            // 
            // trackBarZoom
            // 
            this.trackBarZoom.LargeChange = 100;
            this.trackBarZoom.Location = new System.Drawing.Point(804, 351);
            this.trackBarZoom.Maximum = 500;
            this.trackBarZoom.Minimum = 40;
            this.trackBarZoom.Name = "trackBarZoom";
            this.trackBarZoom.Size = new System.Drawing.Size(165, 45);
            this.trackBarZoom.SmallChange = 20;
            this.trackBarZoom.TabIndex = 4;
            this.trackBarZoom.TickFrequency = 20;
            this.trackBarZoom.Value = 100;
            this.trackBarZoom.ValueChanged += new System.EventHandler(this.OnZoomLevelChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(855, 335);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Zoom Level:";
            // 
            // panelDrawBackground
            // 
            this.panelDrawBackground.AutoScroll = true;
            this.panelDrawBackground.Controls.Add(this.drawPanel);
            this.panelDrawBackground.Location = new System.Drawing.Point(14, 90);
            this.panelDrawBackground.Name = "panelDrawBackground";
            this.panelDrawBackground.Size = new System.Drawing.Size(769, 460);
            this.panelDrawBackground.TabIndex = 6;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(438, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 13);
            this.label13.TabIndex = 14;
            this.label13.Text = "Generations:";
            // 
            // nupGenerations
            // 
            this.nupGenerations.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nupGenerations.Location = new System.Drawing.Point(511, 20);
            this.nupGenerations.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nupGenerations.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nupGenerations.Name = "nupGenerations";
            this.nupGenerations.Size = new System.Drawing.Size(54, 20);
            this.nupGenerations.TabIndex = 15;
            this.nupGenerations.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // nupIterations
            // 
            this.nupIterations.Location = new System.Drawing.Point(511, 44);
            this.nupIterations.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.nupIterations.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nupIterations.Name = "nupIterations";
            this.nupIterations.Size = new System.Drawing.Size(54, 20);
            this.nupIterations.TabIndex = 16;
            this.nupIterations.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(452, 47);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 17;
            this.label14.Text = "Iterations:";
            // 
            // Solver
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 562);
            this.Controls.Add(this.panelDrawBackground);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.trackBarZoom);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.resultsPanel);
            this.Controls.Add(this.controlPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximumSize = new System.Drawing.Size(1000, 600);
            this.MinimumSize = new System.Drawing.Size(1000, 600);
            this.Name = "Solver";
            this.Text = "Contour Approximation";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnFormClosed);
            this.Resize += new System.EventHandler(this.WindowResize);
            this.controlPanel.ResumeLayout(false);
            this.controlPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupControlPoints)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupCurveDegree)).EndInit();
            this.resultsPanel.ResumeLayout(false);
            this.resultsPanel.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarZoom)).EndInit();
            this.panelDrawBackground.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nupGenerations)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupIterations)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel drawPanel;
        private System.Windows.Forms.GroupBox controlPanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label imageFileName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelPoints;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox resultsPanel;
        private System.Windows.Forms.Label labelBestFitness;
        private System.Windows.Forms.Label labelGenerations;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nupCurveDegree;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelPopulationSize;
        private System.Windows.Forms.Label labelDiversity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBoxRandomDraft;
        private System.Windows.Forms.CheckBox checkBoxApproximationDraft;
        private System.Windows.Forms.CheckBox checkBoxOriginalDraft;
        private System.Windows.Forms.CheckBox checkBoxControlPoints;
        private System.Windows.Forms.CheckBox checkBoxRandomControlPoints;
        private System.Windows.Forms.Label labelMSD;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nupControlPoints;
        private System.Windows.Forms.ToolTip toolTipISE;
        private System.Windows.Forms.ToolTip toolTipMSD;
        private System.Windows.Forms.Label labelMaximalError;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox checkBoxAdaptive;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TrackBar trackBarZoom;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelDrawBackground;
        private System.Windows.Forms.NumericUpDown nupGenerations;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown nupIterations;
    }
}