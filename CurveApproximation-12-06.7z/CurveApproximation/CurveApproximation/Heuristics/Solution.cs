﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace CurveApproximation.Heuristics {

    class Solution {

        //========================================================
        /// <summary> The solution curve </summary>
        private Curves.NURBS curve;
        public Curves.NURBS Curve {
            get { return curve; }
        }

        /// <summary> The DE strategy used in this solution  (for self-adaptive) </summary>
        private Strategy strategy;
        public Strategy GetStrategy {
            get { return strategy; }
        }

        /// <summary> The crossover rate used for this solution (for self-adaptive) </summary>
        private int crossoverRate;
        public int CR {
            get { return crossoverRate; }
        }

        /// <summary> The differential weight used for this solution (for self-adaptive) </summary>
        private int differentialWeight;
        public int F {
            get { return differentialWeight; }
        }

        private int generation;
        public int Generation {
            get { return generation; }
        }

        /// <summary> The points that compose the NURBS curve for this solution. </summary>
        private HashSet<PointF> points;
        public HashSet<PointF> Points {
            get { return points; }
        }

        /// <summary> The pixels (points discretized) that compose the NURBS curve for this solution. </summary>
        private HashSet<Point> pixels;
        public HashSet<Point> Pixels {
            get { return pixels; }
        }

        /// <summary> Matrix Squared Difference </summary>
        private double msd = int.MaxValue;
        public double MSD {
            get { return msd; }
        }

        /// <summary> Integral Square Error </summary>
        private double ise = Double.MaxValue;
        public double ISE {
            get { return ise; }
        }

        /// <summary> Maximal Error </summary>
        private double maxE = Double.MaxValue;
        public double MaxE {
            get { return maxE; }
        }

        /// <summary> The fitness of this solution. It's initial value is the minimum value possible (i.e. not computed yet) </summary>
        private double fitness = Double.MinValue;
        public double Fitness {
            get { return fitness; }
        }
        //========================================================




        //========================================================
        public Solution( Curves.NURBS curve , int crossoverRate , int differentialWeight, Strategy strategy = Strategy.DE1randbin ) {
            this.curve = curve;
            this.crossoverRate = crossoverRate;
            this.differentialWeight = differentialWeight;
            this.strategy = strategy;
        }
        //========================================================




        //========================================================
        /// <summary>
        /// Clones the solution (without maintaining pointers)
        /// </summary>
        public Solution clone() {
            Solution newSolution = new Solution( this.curve , crossoverRate , differentialWeight , strategy );
            newSolution.pixels = new HashSet<Point>( pixels );
            newSolution.points = new HashSet<PointF>( points );
            newSolution.fitness = this.fitness;
            newSolution.ise = this.ise;
            newSolution.msd = this.msd;
            newSolution.maxE = this.maxE;
            return newSolution;
        }
        //========================================================



        //========================================================
        /// <summary>
        /// Updates the crossover rate and the differential weight reseting the generation to zero.
        /// </summary>
        /// <param name="cr"> The new crossover rate. </param>
        public void updateAdaptive(int cr, int f) {
            this.generation = 0;
            this.crossoverRate = cr;
            this.differentialWeight = f;
        }
        //========================================================
        




        //========================================================
        /// <summary>
        /// Computes the fitness of a given solution (curve) based on the similarity
        /// with a given objective (list of pixels).
        /// </summary>
        /// <param name="objective"> The list of pixels used as objective. </param>
        /// <returns> A value representing the euclidean distance between the solution countor and the objetive countor </returns>
        public double computeFitness( List<Point> objective ){
            if( this.fitness >= 0 ) return this.fitness; // if fitness was already calculated

            points = new HashSet<PointF>();
            pixels = new HashSet<Point>();

            // compute all points/pixels generated by the curve
            double delta = 1.0 / ( Program.CurveSamples * this.curve.getSize() );
            List<Point> segment;
            PointF startF, endF;
            Point start = new Point();
            Point end = new Point();

            startF = this.curve.getPointAt( 0 );
            points.Add( startF );

            for( double t = delta ; t <= 1 ; t += delta ) {
                if( t > 1 ) t = 1;
                endF = this.curve.getPointAt( t );
                Toolbox.PointFtoPoint( ref start , startF );
                Toolbox.PointFtoPoint( ref end , endF );
                points.Add( endF );

                segment = Toolbox.GetPointsInSegment(start, end);
                foreach (Point point in segment)
                    pixels.Add( point );
                
                startF = endF;
            }

            int[] distFromObjective, distFromSolution;
            Toolbox.ComputeMinDistance( objective, pixels, out distFromObjective, out distFromSolution );
            if (distFromObjective.Length != objective.Count || distFromSolution.Length != pixels.Count)
                new Exception("ERROR: Compute Minimum Distance Failed!");

            this.msd = 0;
            foreach (int v in distFromObjective)    this.msd += v;
            foreach (int v in distFromSolution)     this.msd += v;
            this.ise = Toolbox.ComputeISE( objective , points , ref this.maxE );

            this.fitness = this.ise;
            if (fitness < 0)
                fitness = -1;
            return this.fitness;
        }
        //========================================================

    }

}

