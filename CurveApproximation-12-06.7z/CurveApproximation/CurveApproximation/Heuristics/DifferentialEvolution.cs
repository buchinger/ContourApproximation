﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;


namespace CurveApproximation.Heuristics {

    enum Strategy { DE1randbin , DE2curbestbin };

    class DifferentialEvolution {

        // Metaheuristics main parameters
        int crossoverProbability = 800; // value in %o
        int crossoverDeviation = 100; // value in %o
        int differentialWeight = 500; // value in %o
        int differentialDeviation = 100; // value in %o
        int populationSize = 50;
        double NMDF = double.MinValue; // Normalization with Maximum Diversity so far
        double diversity;

        const int MAX_CRP = 950;
        const int MIN_CRP = 250;
        const int MAX_F = 1500;
        const int MIN_F = 100;

        List<Point> objective;
        List<Solution> candidates;
        List<Solution> trial;
        Solution bestSolution;
        
        int maxGenerations;
        int currentGeneration;
        int curveDegree;
        int controlPoints;

        //--------------------------
        // Adaptive parameters
        bool adaptive;
        int p1, p2;
        int ns1, ns2, nf1, nf2;
        const int learning_period = 50;
        const int change_cr = 5;
        const int update_crm = 25;
        List<int> crossoverPool;
        List<int> differentialPool;
        //--------------------------

        float _posLowerBound = -5.0f;
        float _posUpperBound = 5.0f;
        float _weightLowerBound = 0.5f;
        float _weightUpperBound = 1.5f;


        //=====================================================================
        /// <summary>
        /// Starts an optimization process using Differential Evolution
        /// </summary>
        /// <param name="objective"> A list of points as objetive to approximate. </param>
        /// <param name="controlPoints"> The number of control points to use in the parametric curves. </param>
        /// <param name="curveDegree"> The degree to use in the parametric curves. </param>
        /// <param name="adaptive"> Especify if the adaptive approach should be used. </param>
        /// <param name="iterations"> The maximum number of iterations/generations allowed (default = MaxInt). </param>
        public DifferentialEvolution( List<Point> objective, int controlPoints, int curveDegree, bool adaptive, int iterations = 1000 ) {
            this.curveDegree = curveDegree;
            this.controlPoints = controlPoints > curveDegree ? controlPoints : curveDegree+1;
            this.maxGenerations = iterations;
            this.currentGeneration = 1;
            this.adaptive = adaptive;
            this.populationSize = Math.Min( 20 * controlPoints , 100 );
            this.objective = new List<Point>( objective );
            this.candidates = new List<Solution>();
            this.trial = new List<Solution>();
            Curves.NURBS.ClearPDDictionary();

            if (adaptive) {
                p1 = p2 = 500;
                ns1 = ns2 = nf1 = nf2 = 0;
                crossoverPool = new List<int>();
                differentialPool = new List<int>();
            }

            generatePopulation( );
            evolve( );
        }
        //=====================================================================





        //=====================================================================
        /// <summary>
        /// Update the new probability of using both strategies
        /// </summary>
        private void updateAdaptiveParameters() {
            // Check if strategy should be updated
            if (this.currentGeneration % learning_period == 0) {
                p1 = Convert.ToInt32( Math.Round( (1000.0 * ns1 * (ns2 + nf2)) / (ns2 * (ns1 + nf1) + ns1 * (ns2 + nf2)) ) );
                p2 = 1000 - p1;
                ns1 = ns2 = nf1 = nf2 = 0;
            }

            // Check if the crossover and differential weight mean should be updated
            if (this.currentGeneration % update_crm == 0) {
                // Crossover Update
                if (crossoverPool.Count > 5) {
                    double mean = 0;
                    foreach (int v in crossoverPool)
                        mean += v;
                    mean = mean / crossoverPool.Count;
                    this.crossoverProbability = Convert.ToInt32( Math.Round( mean ) );
                }
                crossoverPool.Clear();

                // Differential Weight Update
                if( differentialPool.Count > 5) {
                    double mean = 0;
                    foreach (int v in differentialPool)
                        mean += v;
                    mean = mean / differentialPool.Count;
                    this.differentialWeight = Convert.ToInt32( Math.Round( mean ) );
                }
                differentialPool.Clear();
            }

            // Check if individuals crossover should be updated
            foreach(Solution s in candidates) {
                if (s.Generation > change_cr) {
                    int cr = choseCrossoverRate();
                    int f = choseDifferentialWeight();
                    s.updateAdaptive( cr, f );
                }
            }
            
        }
        //=====================================================================




        //=====================================================================
        /// <summary>
        /// Randomly selects a strategy for a solution using the probabilites p1 and p2
        /// </summary>
        private Strategy choseStrategy() {
            int r = Toolbox.GetRandomInt( 0, 1000 );
            if (r < p1) return Strategy.DE1randbin;
            return Strategy.DE2curbestbin;
        }
        //=====================================================================


        //=====================================================================
        /// <summary>
        /// Generate a crossover rate based on the crossover mean and its standart deviation
        /// </summary>
        private int choseCrossoverRate() {
            int deviation2 = this.crossoverDeviation / 2;
            int cr = this.crossoverProbability + (Toolbox.GetRandomInt( 0, this.crossoverDeviation ) - deviation2);
            cr = Math.Min( cr , MAX_CRP );
            cr = Math.Max( cr , MIN_CRP );
            return cr;
        }
        //=====================================================================



        //=====================================================================
        /// <summary>
        /// Generate a differential weight based on the differential mean and its standart deviation
        /// </summary>
        private int choseDifferentialWeight() {
            int deviation2 = this.differentialDeviation / 2;
            int f = this.differentialWeight + (Toolbox.GetRandomInt( 0, this.differentialDeviation ) - deviation2);
            f = Math.Min( f, MAX_F );
            f = Math.Max( f, MIN_F );
            return f;
        }
        //=====================================================================




        //=====================================================================
        /// <summary>
        /// This method creates the initial population
        /// </summary>
        public void generatePopulation( ) {
            for( int c = 0 ; c < populationSize ; c++ ) {
                List<Point> cpsAux = new List<Point>();
                List<PointF> cps = new List<PointF>();
                List<double> weights = new List<double>();

                // If the objective is a contour of non-ordered points
                if( Program.Operation == FittingType.NonOrderedPoints ){
                    cpsAux = Toolbox.GetNRandomElements( objective , controlPoints );  // get n random elements from objective
                }
                
                // If the objective is a contour of ordered points
                else if( Program.Operation == FittingType.OrderedPoints ){
                    cpsAux.Add( objective[0] ); // First contour point should be used assuredly
                    // Select other points randomly but in incremental subspaces
                    float delta = ((float) (objective.Count - 2)) / (controlPoints - 2);
                    float d = 1.0f;
                    for( int i = 0 ; i < controlPoints - 2 ; i++ ) {
                        int a = Convert.ToInt32( Math.Ceiling( d ) );
                        d += delta;
                        int b = Convert.ToInt32( Math.Floor( d ) );
                        int index = Toolbox.GetRandomInt( a, b );
                        cpsAux.Add( objective[index] );
                    }
                    cpsAux.Add( objective[ objective.Count-1 ] ); // Last contour point should be used assuredly
                }

                else{
                    new Exception("No valid operation selected!");
                }

                // Applying some noise over the original objetive points
                for(int i=0; i<cpsAux.Count; i++){
                    float xDelta, yDelta;
                    if( i == 0 || i == cpsAux.Count - 1 )
                        xDelta = yDelta = 0;
                    else {
                        xDelta = (Toolbox.GetRandomInt( 0, 1000 ) / 1000.0f) * (this._posUpperBound - this._posLowerBound) + this._posLowerBound;
                        yDelta = (Toolbox.GetRandomInt( 0, 1000 ) / 1000.0f) * (this._posUpperBound - this._posLowerBound) + this._posLowerBound;
                    }
                    PointF pf = new PointF( cpsAux[i].X + xDelta, cpsAux[i].Y + yDelta );
                    cps.Add( pf );
                }
                // Applying some diversity over weight values
                for(int i=0; i<this.controlPoints; i++){
                    float wDelta = (Toolbox.GetRandomInt(0,1000) / 1000.0f) * (this._weightUpperBound - this._weightLowerBound) + this._weightLowerBound;
                    weights.Add( wDelta );
                }

                Curves.NURBS curve = new Curves.NURBS( this.curveDegree, cps, weights );
                candidates.Add( new Solution(curve , choseCrossoverRate() , choseDifferentialWeight() , choseStrategy() ) );
            }

            candidates[0].computeFitness( this.objective ); // use this for fill the NURBS PD dictionary without race conditions
            bestSolution = candidates[0]; // Assume the first solution as the best and update it latter
            computeFitness( candidates );
            updateBest();
        }
        //=====================================================================



        
        //=====================================================================
        /// <summary>
        /// Computes the fitness for every solution in the given list using threads
        /// </summary>
        private void computeFitness( List<Solution> target ) {
            int cores = Math.Max( 1 , Environment.ProcessorCount-1 );
            int delta = Math.Max( target.Count / cores , 1);

            List<Thread> threads = new List<Thread>();
            int begin = 0;

            do {
                int max = Math.Min( begin+delta , target.Count );
                ComputeFitnessWorker work = new ComputeFitnessWorker(target, objective, begin, max);
                threads.Add( new Thread( work.run ) );
                begin = max;
            } while( begin < target.Count );

            foreach( Thread t in threads ) // Start every thread
                t.Start();
            foreach( Thread t in threads ) // Wait untill every thread finishes its job
                t.Join();
        }
        //=====================================================================
        class ComputeFitnessWorker {
            List<Solution> target;
            List<Point> objective;
            int begin, end;
            public ComputeFitnessWorker( List<Solution> t, List<Point> obj, int a, int b ) {
                target = t;
                objective = obj;
                begin = a; end = b;
            }
            public void run() {
                //Console.WriteLine( "thread responsible for - :" + begin + " - " + end );
                for( int i = begin ; i < end ; i++ ) {
                    target[i].computeFitness( objective );
                    //Console.WriteLine( "thread - i:" + i + " =>" + target[i].Fitness );
                }
            }
        }
        //=====================================================================



        //=====================================================================
        /// <summary>
        /// Find the best candidate solution 
        /// </summary>
        private void updateBest( ) {
            bool newBest = false;
            foreach( Solution s in candidates ) {
                if( s.Fitness < this.bestSolution.Fitness ) {
                    this.bestSolution = s.clone();
                    newBest = true;
                }
            }

            if( newBest )
                Program.ChangeBestSolution( this.bestSolution );
        }
        //=====================================================================




        //=====================================================================
        /// <summary>
        /// Compute and update the diversity in the screen
        /// </summary>
        private void updateDiversity() {
            this.diversity = 0;
            double aux1, aux2;
            int dimensions = candidates[0].Curve.getSize();

            for(int a=0; a<candidates.Count-1; a++) {
                aux2 = double.MaxValue;
                for(int b=a+1; b<candidates.Count; b++) {
                    aux1 = 0;

                    List<PointF> cpsA = candidates[a].Curve.getControlPoints();
                    List<PointF> cpsB = candidates[b].Curve.getControlPoints();
                    List<double> wA = candidates[a].Curve.getWeights();
                    List<double> wB = candidates[b].Curve.getWeights();
                    for (int d=0; d<dimensions; d++) {
                        aux1 += (Math.Pow( cpsA[d].X - cpsB[d].X, 2 ));
                        aux1 += (Math.Pow( cpsA[d].Y - cpsB[d].Y, 2 ));
                        aux1 += (Math.Pow( wA[d] - wB[d], 2 ));
                    }
                    aux1 = Math.Sqrt( aux1 ) / dimensions;
                    if (aux1 < aux2)
                        aux2 = aux1;
                }
                this.diversity += Math.Log( 1.0f + aux2 );
            }

            if (this.NMDF < this.diversity)
                this.NMDF = this.diversity;

            this.diversity = this.diversity / this.NMDF;
        }
        //=====================================================================





        //==============================================================
        /// <summary>
        /// Perform the mainstream of differential evolution process.
        /// </summary>
        private void evolve() {
            do {
                // check if the user asked to stop the evolution
                if (Program.StopEvolution) {
                    Program.EvolutionStoped();
                    return;
                }

                mutationCrossover();
                selection();

                nextGeneration();

                Console.Write( this.bestSolution.Fitness + "; " + this.diversity + "; " + this.bestSolution.MSD + "; " + this.bestSolution.MaxE );
                if (adaptive) Console.WriteLine( "; " + this.p1 + "; " + this.p2 + "; " + this.crossoverProbability + "; " + this.differentialWeight );
                else Console.WriteLine( "" );
                    
            } while (this.currentGeneration < this.maxGenerations && this.bestSolution.Fitness>0);
        }
        //==============================================================



        //==============================================================
        /// <summary>
        /// Called in the end of each generation
        /// </summary>
        private void nextGeneration() {
            this.currentGeneration++;
            int randomIndex = Toolbox.GetRandomInt( 0, candidates.Count - 1 );
            Program.ChangeGeneration( this.currentGeneration, this.candidates.Count, this.diversity, this.candidates[randomIndex] );

            if( this.adaptive )
                updateAdaptiveParameters();
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Implements the mutation and crossover operators of differential evolution with multiple threads
        /// </summary>
        private void mutationCrossover() {
            this.trial.Clear();
            this.trial = new List<Solution>( this.candidates );

            int cores = Math.Max( 1 , Environment.ProcessorCount-1 );
            int delta = Math.Max( candidates.Count / cores, 1 );
            List<Thread> threads = new List<Thread>();
            int begin = 0;

            do {
                int max = Math.Min( begin + delta, candidates.Count );
                MutationCrossoverWorker work = new MutationCrossoverWorker( candidates, trial, objective, begin, max, choseCrossoverRate(), choseDifferentialWeight(), this.curveDegree, choseStrategy(), this.bestSolution );
                threads.Add( new Thread( work.run ) );
                begin = max;
            } while( begin < candidates.Count );

            foreach( Thread t in threads ) // Start every thread
                t.Start();

            //int tindex = 0;
            foreach( Thread t in threads ){ // Wait untill every thread finishes its job
                //Console.WriteLine( "Waiting Thread " + tindex ); tindex++;
                t.Join();
                
            }
        }
        //==============================================================
        class MutationCrossoverWorker {
            List<Solution> candidate;
            List<Solution> trial;
            List<Point> objective;
            int begin, end;
            int CR, curveDegree;
            int differentialWeight;
            Strategy strategy;
            Solution best;
            //------------------------------------
            public MutationCrossoverWorker( List<Solution> candidate, List<Solution> trial, List<Point> obj, int a, int b, int CR, int F, int degree, Strategy strategy, Solution best ) {
                this.candidate = candidate;
                this.trial = trial;
                this.objective = obj;
                this.begin = a;
                this.end = b;
                this.CR = CR;
                this.differentialWeight = F;
                this.curveDegree = degree;
                this.strategy = strategy;
                this.best = best;
            }
            //------------------------------------
            public void run() {
                //Console.WriteLine( "thread responsible for - :" + begin + " - " + end );
                int cps = candidate[begin].Curve.getControlPoints().Count;
                float F = differentialWeight / 1000.0f;

                //------- Mutation & Crossover -------
                for ( int target = begin ; target < end ; target++ ) {                    
                    Curves.NURBS curve;
                    List<PointF> controlPoints = new List<PointF>();
                    List<double> weights = new List<double>();

                    int basis,a,b;
                    basis = Toolbox.GetRandomInt( 0 , candidate.Count - 1 );
                    do {
                        a = Toolbox.GetRandomInt( 0, candidate.Count - 1 );
                    } while( a == basis );
                    do {
                        b = Toolbox.GetRandomInt( 0, candidate.Count - 1 );
                    } while( b == basis || b == a );

                    PointF ptf = new PointF();
                    double w;
                    int k = Toolbox.GetRandomInt( 1, cps-2 );
                    for( int i = 0 ; i < cps ; i++ ) {
                        // mutate and crossover the position (x & y) and the weight
                        int x = Toolbox.GetRandomInt( 0, 1000 );
                        if( (x <= CR && i>0 && i<cps-1) || i==k ){
                            ptf.X = candidate[basis].Curve.getControlPoint(i).X +  F * (candidate[a].Curve.getControlPoint( i ).X - candidate[b].Curve.getControlPoint( i ).X);
                            ptf.Y = candidate[basis].Curve.getControlPoint(i).Y +  F * (candidate[a].Curve.getControlPoint( i ).Y - candidate[b].Curve.getControlPoint( i ).Y);
                            w = candidate[basis].Curve.getWeight( i ) + F * (candidate[a].Curve.getWeight( i ) - candidate[b].Curve.getWeight( i ));
                            if( strategy == Strategy.DE2curbestbin) {
                                ptf.X += F * (best.Curve.getControlPoint( i ).X - candidate[basis].Curve.getControlPoint( i ).X);
                                ptf.Y += F * (best.Curve.getControlPoint( i ).Y - candidate[basis].Curve.getControlPoint( i ).Y);
                                w += F * (best.Curve.getWeight( i ) - candidate[basis].Curve.getWeight( i ));
                            }
                        }
                        else{
                            ptf = candidate[target].Curve.getControlPoint(i);
                            w = candidate[target].Curve.getWeight(i); 
                        }
                        controlPoints.Add( ptf );   
                        weights.Add(w);
                    }

                    // Creates the new solution instance and compute its fitness. Place the solution in the trial list
                    curve = new Curves.NURBS( curveDegree, controlPoints, weights );
                    Solution newSolution = new Solution( curve , CR , differentialWeight , strategy );
                    newSolution.computeFitness( objective );
                    trial[ target ] = newSolution;
                    // Console.WriteLine( "Trial #" + target + " => Fitness = " + newSolution.Fitness );
                }
            }
        }
        //==============================================================





        //==============================================================
        /// <summary>
        /// Implements the selection operator of the Differential Evolution
        /// </summary>
        private void selection(){
            if( candidates.Count != trial.Count )
                new Exception("ERROR: # candidates != # trial candidates");

            for( int i = 0 ; i < candidates.Count ; i++ ) {
                // trial candidate is better or equal than the candidate in position i
                if (trial[i].Fitness <= candidates[i].Fitness) {
                    if (this.adaptive) {
                        if (trial[i].GetStrategy == Strategy.DE1randbin) this.ns1++;
                        else this.ns2++;
                        crossoverPool.Add( trial[i].CR );
                        differentialPool.Add( trial[i].F );
                    }
                    candidates[i] = trial[i];
                }
                else { // trial candidate has been discarted
                    if (this.adaptive) {
                        if (trial[i].GetStrategy == Strategy.DE1randbin) this.nf1++;
                        else this.nf2++;
                    }
                }
            }

            updateBest();
            updateDiversity();
        }
        //==============================================================

    }

}
