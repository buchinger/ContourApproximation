﻿using System;

namespace CurveApproximation {


    public class Pixel {
        public int x, y;
        public Pixel() {
            x = y = 0;
        }
        public Pixel(int a, int b) {
            x = a;
            y = b;
        }
        public Pixel(Pixel a) {
            x = a.x;
            y = a.y;
        }
        public static Pixel operator *(Pixel p, double m) {
            Pixel res = new Pixel( Convert.ToInt32( p.x * m ), Convert.ToInt32( p.y * m) );
            return res;
        }
        public static Pixel operator +(Pixel p, Pixel q) {
            Pixel res = new Pixel( p.x+q.x , p.y+q.y );
            return res;
        }
    }




    public class Vec3 {
        public double x, y, z;
        public Vec3() {
            x = y = z = 0;
        }
        public Vec3(double a, double b, double c = 0) {
            x = a;
            y = b;
            z = c;
        }
        public void assign(double a, double b, double c = 0) {
            x = a;
            y = b;
            z = c;
        }
        public double at(uint index) {
            switch (index) {
                case 0: return x;
                case 1: return y;
                case 2: return z;
            }
            throw new ArgumentException();
        }
        public static Vec3 operator *(Vec3 v, double m) {
            Vec3 res = new Vec3( v.x * m, v.y * m, v.z * m );
            return res;
        }
        public static Vec3 operator *(Vec3 v, int m) {
            Vec3 res = new Vec3( v.x * m, v.y * m, v.z * m );
            return res;
        }
        public static Vec3 operator +(Vec3 a, Vec3 b) {
            Vec3 res = new Vec3( a.x + b.x, a.y + b.y, a.z + b.z );
            return res;
        }
        public static Vec3 operator -(Vec3 a, Vec3 b) {
            Vec3 res = new Vec3( a.x - b.x, a.y - b.y, a.z - b.z );
            return res;
        }
        public static Vec3 operator /(Vec3 v, double d) {
            if (d == 0) return new Vec3( Double.NaN, Double.NaN, Double.NaN );
            Vec3 res = new Vec3( v.x / d, v.y / d, v.z / d );
            return res;
        }
        public void normalize() {
            double norma = Math.Sqrt( x * x + y * y + z * z );
            x = x / norma;
            y = y / norma;
            z = z / norma;
        }
        public void print() {
            Console.WriteLine( "x=" + x + " / y=" + y + " / z=" + z );
        }
    }
}
