﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace CurveApproximation.Curves {

    /// <summary>
    /// NURBS is defined by several control points, curve degree, knot vector and weight vector.
    /// #knots = #controlPoints + degree+1.
    /// #weights = #controlPoints
    /// </summary>
    public class NURBS {

        /// <summary>
        /// Stores all deBoor coeficients (binded to the knot vector - so each NURBS has it own boor dictionary)
        /// </summary>
        private static Dictionary<Vec3, double> BoorCalculated = new Dictionary<Vec3, double>(new MyComparer());

        private int curve_degree;
        private int K;
        private List<PointF> control_points;
        private List<double> knot_values;
        private List<double> weight_values;
        private Dictionary<double, PointF> curve_points = new Dictionary<double, PointF>();





        //=========================================================================
        /// <summary>
        /// Required for the SortedDictionary used for Dynamic Programmin
        /// </summary>
        private class MyComparer : IEqualityComparer<Vec3> {
            public bool Equals(Vec3 a, Vec3 b) {
                return a.x == b.x && a.y == b.y && a.z == b.z;
            }
            public int GetHashCode(Vec3 obj) {
                return ("" + obj.x + "-" + obj.y + "-" + obj.z).GetHashCode();
            }
        }
        //=========================================================================





        //=========================================================================
        /// <summary>
        /// Initialize a NonUniform Rational BSpline curve with a knot vector, curve degree,
        /// list of control points, and list of weights
        /// </summary>
        /// <param name="knots">The list of knot values (knot vector).</param>
        /// <param name="weights">The list of weights values.</param>
        /// <param name="degree">The curve degree.</param>
        /// <param name="cps">The list of control points.</param>
        public NURBS(List<double> knots, List<double> weights, int degree, List<PointF> cps) {
            K = degree + 1;
            if (knots.Count != cps.Count + K) throw new ArgumentException();
            if (weights.Count != cps.Count) throw new ArgumentException();
            control_points = new List<PointF>( cps );
            knot_values = new List<double>( knots );
            weight_values = new List<double>( weights );
            curve_degree = degree;
        }
        //=========================================================================
        
            
        //=========================================================================
        /// <summary>
        /// Initialize a NonUniform Rational BSpline curve with a knot vector, curve degree,
        /// list of control points, and list of weights
        /// </summary>
        /// <param name="degree">The curve degree</param>
        /// <param name="cps">The list of control points.</param>
        public NURBS(int degree, List<PointF> cps, List<double> weights = null) {
            K = degree + 1;
            int n = cps.Count;
            int m = n + K;
            double delta = 1.0 / (n - K + 1);
            double knot = delta;

            //Console.WriteLine( "n="+n+" / K="+K );
            //Console.WriteLine( "knot vector:" );
            knot_values = new List<double>( );
            for(int i=0; i<K; i++) knot_values.Add(0);
            for(int i=K; i<n; i++, knot+=delta) knot_values.Add( knot );
            for(int i=n; i<m; i++) knot_values.Add(1);
            //foreach (double v in knot_values) Console.Write( " " + v );
            //Console.WriteLine(""); 

            if( weights == null ) {
                this.weight_values = new List<double>();
                for( int i = 0 ; i < n ; i++ ) this.weight_values.Add( 1 );
            }
            else
                this.weight_values = new List<double>( weights );

            this.curve_degree = degree;
            this.control_points = new List<PointF>( cps );
        }
        //=========================================================================



        //=========================================================================
        /// <summary>
        /// It must be used when a new type of NURBS is used
        /// </summary>
        public static void ClearPDDictionary() {
            BoorCalculated.Clear();
        }
        //=========================================================================



        //=========================================================================
        /// <summary>
        /// Calculates deBoor coeficients
        /// </summary>
        /// <param name="i"></param>
        /// <param name="k"></param>
        /// <param name="t"></param>
        /// <param name="knot_vector"></param>
        /// <returns></returns>
        [System.Runtime.CompilerServices.MethodImpl( System.Runtime.CompilerServices.MethodImplOptions.Synchronized )]
        public double coxDeBoor(int i, int k, double t) {
            // Console.WriteLine("deBoorsRecursion: " + i + " " + k + " " + t);
            if (k == 1) {
                if (t+Double.Epsilon >= 1.0) {
                    if (t <= knot_values[i+1] + Double.Epsilon && t+Double.Epsilon >= knot_values[i]) return 1;
                    else return 0;
                }
                else {
                    if (t < knot_values[i + 1] && t >= knot_values[i] - Double.Epsilon) return 1;
                    else return 0;
                }
            }

            Vec3 param = new Vec3(i, k, t);
            if (BoorCalculated.ContainsKey(param)) { // Dynamic Programing o//
                return BoorCalculated[param];
            }

            double boors = 0;
            // Console.WriteLine("Boors accessing indexes: " + (i + k) + " / "+knot_vector.Count);
            double denominator = (knot_values[i + k - 1] - knot_values[i]);
            if (denominator > 0)
                boors = ((t - knot_values[i]) / denominator) * coxDeBoor(i, k - 1, t);
            denominator = (knot_values[i + k] - knot_values[i + 1]);
            if (denominator > 0)
                boors += ((knot_values[i + k] - t) / denominator) * coxDeBoor(i + 1, k - 1, t);

            BoorCalculated.Add( param , boors );
            return boors;
        }
        //=========================================================================




        //=========================================================================
        /// <summary>
        /// Returns the points of this curve at a given parameter between [0,1]
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public PointF getPointAt(double t) {
            // First check if the curve point was already calculated
            if (curve_points.ContainsKey(t))
                return curve_points[t];

            // If the curve point was not already calculated, we calculate it and store the result for future use
            int n = control_points.Count;
            int k = curve_degree + 1;
            double resX, resY;
            double boors = 0;
            double boors_sum = 0;
            double weight_sum = 0;

            resX = resY = 0;
            for (int i = 0; i < n; i++) {
                Vec3 param = new Vec3(i, k, t);
                if (BoorCalculated.ContainsKey(param)) { // Dynamic Programing =)
                    boors = BoorCalculated[param];
                }
                else {
                    if (t == 1)
                        t=1;
                    boors = coxDeBoor(i, k, t);
                }

                boors_sum += boors;
                weight_sum += weight_values[i] * boors;
                resX = resX + (control_points[i].X * boors * weight_values[i]);
                resY = resY + (control_points[i].Y * boors * weight_values[i]);
            }

            // Generating the resulting final point
            PointF res;
            
            // If the boors_sum is not 1 (or almost one) the value of parameter t cannot be used
            if( boors_sum < 0.99 ) {
                res = new PointF( -1, -1 );
                Console.WriteLine( "NURBS: boors_sum < 1 => t=" + t + " -> boors_sum=" + boors_sum );
            }
            else {
                resX = resX * (1.0 / weight_sum);
                resY = resY * (1.0 / weight_sum);
                res = new PointF( (float) resX, (float) resY );
            }
            
            // Console.WriteLine("res(" + t + ") = " + res.x + " - " + res.y);
            curve_points.Add( t , res);
            return res;
        }
        //=========================================================================







        //=========================================================================
        public int getDegree() {
            return curve_degree;
        }
        //=========================================================================
        public int getSize() {
            return control_points.Count();
        }
        //=========================================================================


        //=========================================================================
        /// <summary>
        /// Returns the coordinates of a given control point
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public PointF getControlPoint(int index) {
            if (index < 0 || index >= control_points.Count()) return new Point(-1, -1);
            return control_points[index];
        }
        //=========================================================================



        //=========================================================================
        /// <summary>
        /// Return the list of control points from this NURBS
        /// </summary>
        /// <returns></returns>
        public List<PointF> getControlPoints() {
            return control_points;
        }
        //=========================================================================




        //=========================================================================
        /// <summary>
        /// Return the list of control points weights from this NURBS
        /// </summary>
        /// <returns></returns>
        public List<double> getWeights() {
            return weight_values;
        }
        //=========================================================================





        //=========================================================================
        /// <summary>
        /// Return the weight of a given control point from this NURBS
        /// </summary>
        /// <returns></returns>
        public double getWeight(int index) {
            if (index < 0 || index >= weight_values.Count()) return -1;
            return weight_values[index];
        }
        //=========================================================================



        //=========================================================================
        /// <summary>
        /// Changes the weight of a given control point from this NURBS
        /// </summary>
        /// <returns></returns>
        public void setWeight(int index, int value) {
            if (index < 0 || index >= weight_values.Count() || value <= 0) return;
            weight_values[index] = value;
            curve_points.Clear();
        }
        //=========================================================================


        //=========================================================================
        public void moveControlPoint(int index, float x, float y) {
            PointF p = control_points[index];
            p.X = x;
            p.Y = y;
            control_points[index] = p;
            curve_points.Clear();
        }
        //=========================================================================

    }
}
