﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MOG.Curves {
    
    /// <summary>
    /// Hermite Curve is defined by two control points and two vectors
    /// The most known Hermite curve has degree three. Thus, this class
    /// implements just this specific case.
    /// </summary>
    public class Hermite : ICurve {
        private Vec3 cp1; //control point 1
        private Vec3 cp2; //control point 2
        private Vec3 cv1; //control vector 1
        private Vec3 cv2; //control vector 2
        private Vec4 ghx, ghy, ghz; // vector with control elements in x, y and z
        private Dictionary<double, Vec3> curve_points = new Dictionary<double, Vec3>();



        /// <summary>
        /// Hermite constructor method
        /// </summary>
        /// <param name="p1">Control point 1</param>
        /// <param name="v1">Control vector 1</param>
        /// <param name="p2">Control point 2</param>
        /// <param name="v2">Control vector 2</param>
        public Hermite(Point<int> p1, Point<int> v1, Point<int> p2, Point<int> v2) {
            cp1 = new Vec3(p1);
            cp2 = new Vec3(p2);
            cv1 = new Vec3(v1);
            cv2 = new Vec3(v2);
            initiateGhVector();
        }


        /// <summary>
        /// Hermite constructor method
        /// </summary>
        /// <param name="p1">Control point 1</param>
        /// <param name="v1">Control vector 1</param>
        /// <param name="p2">Control point 2</param>
        /// <param name="v2">Control vector 2</param>
        public Hermite(Vec3 p1, Vec3 v1, Vec3 p2, Vec3 v2) {
            cp1 = p1;
            cp2 = p2;
            cv1 = v1;
            cv2 = v2;
            initiateGhVector();
        }

        public void initiateGhVector() {
            ghx = new Vec4(cp1.x, cp2.x, cv1.x - cp1.x, cv2.x - cp2.x);
            ghy = new Vec4(cp1.y, cp2.y, cv1.y - cp1.y, cv2.y - cp2.y);
            ghz = new Vec4(cp1.z, cp2.z, cv1.z - cp1.z, cv2.z - cp2.z);
        }


        public Vec3 getPointAt(double t) {
            // First check if the curve point was already calculated
            if (curve_points.ContainsKey(t))
                return curve_points[t];

            // If the curve point was not already calculated, we calculate it and store the result for future use
            double t2 = t * t;
            double t3 = t2 * t;
            Vec4 parameter_vec = new Vec4((2 * t3 - 3 * t2 + 1), (-2 * t3 + 3 * t2), (t3 - 2 * t2 + t), (t3 - t2));
            Vec3 res = new Vec3(parameter_vec * ghx, parameter_vec * ghy, parameter_vec * ghz);
            curve_points.Add(t, res);
            return res;
        }




        public int getSize() {
            return 2; // it is always two control points
        }




        public Vec3 getControlPoint(int index) {
            if (index == 0) return cp1;
            if (index == 1) return cp2;
            if (index == 2) return cv1;
            else return cv2;
        }

        public List<Vec3> getControlPoints() {
            List<Vec3> list = new List<Vec3>();
            list.Add(cp1);
            list.Add(cv1);
            list.Add(cp2);
            list.Add(cv2);
            return list;
        }




        public int hasControlPointIn(int x, int y, int z = 0) {
            if (Math.Abs(x - cp1.x) <= 2 && Math.Abs(y - cp1.y) <= 2)
                return 0;
            else if (Math.Abs(x - cp2.x) <= 2 && Math.Abs(y - cp2.y) <= 2)
                return 1;
            else if (Math.Abs(x - cv1.x) <= 2 && Math.Abs(y - cv1.y) <= 2)
                return 2;
            else if (Math.Abs(x - cv2.x) <= 2 && Math.Abs(y - cv2.y) <= 2)
                return 3;
            return -1;
        }




        public void moveControlPoint(int index, int x, int y) {
            switch (index) {
                case 0:
                    cp1.x = x;
                    cp1.y = y;
                    break;
                case 1:
                    cp2.x = x;
                    cp2.y = y;
                    break;
                case 2:
                    cv1.x = x;
                    cv1.y = y;
                    break;
                case 3:
                    cv2.x = x;
                    cv2.y = y;
                    break;
            }
            curve_points.Clear();
            initiateGhVector();
        }



        public void translate(int x, int y) {
            cp1.x += x;
            cp1.y += y;
            cp2.x += x;
            cp2.y += y;
            cv1.x += x;
            cv1.y += y;
            cv2.x += x;
            cv2.y += y;
            curve_points.Clear();
            initiateGhVector();
        }




        public void adjustC1(Vec3 tangent) { return; }
        public void adjustC2(Vec3 acceleration) { return; }
        public Vec3 getFirstDerivative(int u) { return null; }
        public Vec3 getSecondDerivative(int u) { return null; }

    }
}
