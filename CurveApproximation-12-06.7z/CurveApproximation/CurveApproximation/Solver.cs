﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.IO;
using System.Drawing.Drawing2D;

namespace CurveApproximation{
    public partial class Solver : Form{

        const int CP_SIZE = 3;
        const int CP_OFFSET = 1;
        int image_offset = 100;
        Size drawPanelSize = new Size(1200,800);
        float zoom = 1f;

        Object dummyContour = new object();
        Pen penOriginal = new Pen( Color.Blue , 1 );
        Pen penApproximation = new Pen( Color.FromArgb( 0xA0, 0xFF, 0x00, 0x00 ) , 1 );
        Pen penControlPoints = new Pen( Color.FromArgb( 0xC0, 0x10, 0x10, 0x10 ) , 1 );
        Pen penRandomSolution = new Pen( Color.FromArgb( 0xA0, 0x99, 0x99, 0x99 ), 1 );
        Pen penRandomSolutionControlPoint = new Pen( Color.FromArgb( 0xA0, 0x55, 0x55, 0x55 ), 1 );
        Thread evolutionThread = null;



        //==============================================================
        public Solver(){
            InitializeComponent();
            Program.EvolutionReady = false;
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// This method is used for painting the main panel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="g"></param>
        private void paint(object sender, PaintEventArgs g){
            bool flagValid;
            g.Graphics.ScaleTransform( this.zoom, this.zoom );
            //g.Graphics.TranslateTransform( -this.zoom * 25, -this.zoom * 25 );
            //if ( zoom > 1.5f )
            //    g.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Draw Original Image (if loaded)
            lock (dummyContour) {
                if (Program.DraftOriginal != null && Program.DraftOriginal.PointCount > 0 && checkBoxOriginalDraft.Checked) {
                    // Check for invalid points (<0)
                    flagValid = true;
                    foreach (PointF p in Program.DraftOriginal.PathPoints) {
                        if (p.X < 0 || p.Y < 0) {
                            flagValid = false;
                            break;
                        }
                    }
                    if (flagValid) {
                        if (Program.Operation == FittingType.OrderedPoints)
                            g.Graphics.DrawPath( penOriginal, Program.DraftOriginal );
                        else {
                            PointF[] points = Program.DraftOriginal.PathPoints;
                            for (int i = 0; i < points.Length; i++)
                                g.Graphics.FillRectangle( penOriginal.Brush, points[i].X, points[i].Y, 1, 1 );
                        }
                    }
                }
            }
               
            // Draw best approximation contour
            if (Program.DraftApproximation != null && Program.DraftApproximation.PointCount > 0 && checkBoxApproximationDraft.Checked ) {
                // Check for invalid points (<0)
                flagValid = true;
                foreach (PointF p in Program.DraftApproximation.PathPoints) {
                    if (p.X < 0 || p.Y < 0) {
                        flagValid = false;
                        break;
                    }
                }
                if (flagValid) {
                    //g.Graphics.DrawPath( penApproximation, Program.DraftApproximation );
                    PointF[] points = Program.DraftApproximation.PathPoints;
                    for (int i = 0; i < points.Length; i++)
                        g.Graphics.FillRectangle( penApproximation.Brush, points[i].X, points[i].Y, 1, 1 );
                }
            }

            // Draw Control Points of the best approximation contour
            if ( Program.ControlPoints != null && checkBoxControlPoints.Checked ) {
                foreach (Point p in Program.ControlPoints) {
                    if (p.X < 0 || p.Y < 0) continue;
                    g.Graphics.FillRectangle( penControlPoints.Brush, p.X - CP_OFFSET, p.Y - CP_OFFSET, CP_SIZE, CP_SIZE );
                }
            }

            // Draw a random solution selected
            if ( Program.DraftRandomSolution != null && Program.DraftRandomSolution.PointCount > 0 && checkBoxRandomDraft.Checked ) {
                flagValid = true;
                foreach (PointF p in Program.DraftRandomSolution.PathPoints)
                    if (p.X < 0 || p.Y < 0) {
                        flagValid = false;
                        break;
                    }
                if( flagValid )
                    g.Graphics.DrawPath( penRandomSolution, Program.DraftRandomSolution );
            }

            // Draw Control Points of the random solution selected
            if (Program.RandomControlPoints != null && checkBoxRandomControlPoints.Checked) {
                foreach (Point p in Program.RandomControlPoints) {
                    if (p.X < 0 || p.Y < 0) continue;
                    g.Graphics.FillRectangle( penRandomSolutionControlPoint.Brush, p.X - CP_OFFSET, p.Y - CP_OFFSET, CP_SIZE, CP_SIZE );
                }
            }
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Reads each pixel of a bitmap image and gets the dark pixels
        /// (transparency, red, green and blue chanels less than 128).
        /// These pixels are included in a list of pixels appling some offset
        /// </summary>
        /// <param name="image"> The bitmap image to be used. </param>
        /// <param name="draft"> The GraphicsPath to be filled with Points (pixels) that were selected in the bitmap image</param>
        /// <param name="offset"> Define if an offset should be used (added) when generating the list of pixels. </param>
        /// <returns> Returns true if the list of pixel could be created or false otherwise. </returns>
        private bool loadImage( Bitmap image, GraphicsPath draft, int offset = 0 ) {
            if (image == null) return false;

            Color color;
            for (int i = 0; i < image.Width; i++) {
                for (int j = 0; j < image.Height; j++) {
                    color = image.GetPixel( i, j );
                    if (color.A <= 127 || (color.R <= 127 && color.B <= 127 && color.B <= 127)) {
                        Point point = new Point( i+image_offset, j+image_offset );
                        draft.AddLine( point , point );
                    }
                }
            }

            return true;
        }
        //==============================================================





        //==============================================================
        /// <summary>
        /// Triggered when browse button is clicked. Open a File Dialog
        /// allowing user to choose which image will be used
        /// </summary>
        private void browseButtonClick(object sender, EventArgs e) {
            OpenFileDialog FD = new OpenFileDialog();
            if (FD.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
                Program.resetDrafts();
                
                // If it is a txt file - text representing the order of pixels in an image
                if( FD.FileName.EndsWith(".txt") ){
                    try {
                        using( TextReader reader = File.OpenText( FD.FileName ) ) {
                            int x, y;
                            string text = reader.ReadToEnd();
                            string[] lines = text.Split( '\n' );

                            Point[] points = new Point[lines.Length-1];
                            for( int i = 0 ; i < lines.Length-1 ; i++ ) {
                                string[] elements = lines[i].Split( ' ' );
                                if( elements.Length < 2 ) continue;
                                int.TryParse( elements[0] , out x );
                                int.TryParse( elements[1] , out y );
                                points[i] = new Point(x + image_offset , y+ image_offset);
                            }
                            Program.DraftOriginal.AddPolygon( points );

                            if ( Program.DraftOriginal.PointCount > 0 ) {
                                Program.Operation = FittingType.OrderedPoints;
                                labelPoints.Text = Program.DraftOriginal.PointCount.ToString() + " - Ordered Points";
                                imageFileName.Text = Toolbox.GetFileName( FD.FileName );
                                buttonStart.Enabled = true;
                                Program.EvolutionReady = true;
                                drawPanel.Size = drawPanelSize;
                                drawPanel.Invalidate();
                            }
                        }
                    } catch( Exception ex ) {
                        MessageBox.Show( "Error while reading the chosen file!\nPlease, select a valid .txt file that represents the image.\n\n"+
                            "The file should have multiple lines with two integers separeted by a space, representing the pixels.", "Error While Chosing Image",
                            MessageBoxButtons.OK, MessageBoxIcon.Error );
                        Console.WriteLine( "Exception:: " + ex.Message );
                        buttonStart.Enabled = false;
                    }
                }

                // If it is a image file - non-ordered pixels in an image
                else if( FD.FileName.EndsWith(".jpg") || FD.FileName.EndsWith( ".png" )){
                    imageFileName.Text = Toolbox.GetFileName( FD.FileName );
                    Bitmap image = new Bitmap( FD.FileName );
                    bool loadResult = loadImage( image , Program.DraftOriginal, image_offset );
                    if (loadResult) {
                        Program.Operation = FittingType.NonOrderedPoints;
                        labelPoints.Text = Program.DraftOriginal.PointCount.ToString() + " - Non-Ordered Points";
                        buttonStart.Enabled = true;
                        Program.EvolutionReady = true;
                        drawPanel.Size = drawPanelSize;
                        drawPanel.Invalidate();
                    }
                    else {
                        MessageBox.Show( "Some error has ocurred when loading the image file.", "Error While Loading Image", MessageBoxButtons.OK, MessageBoxIcon.Error );
                        buttonStart.Enabled = false;
                    }
                            
                }
                else {
                    MessageBox.Show( "The file chosen is invalid!\nPlease, select a .jpg or .png image file for non-ordered image points"+
                        "\nor a .txt file for ordered image points.", "Error While Chosing Image File", MessageBoxButtons.OK, MessageBoxIcon.Error );
                    buttonStart.Enabled = false;
                }
            }
        }
        //==============================================================





        //==============================================================
        /// <summary>
        /// Adjust the Draw Panel according to the window size
        /// </summary>
        private void WindowResize(object sender, EventArgs e) {
            int width = this.Bounds.Width - 45;
            int height;

            Point point = drawPanel.Bounds.Location;
            height = drawPanel.Bounds.Height;
            drawPanel.SetBounds( point.X, point.Y, width, height );
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Triggered when start button is clicked. Generate an initial solution
        /// and starts the Evolutionary Algorithm
        /// </summary>
        private void startButtonClick(object sender, EventArgs e) {
            if ( Program.EvolutionReady ) {
                // Change form values
                buttonStart.Text = "Stop";
                labelBestFitness.Text = "-";
                labelMaximalError.Text = "-";
                labelMSD.Text = "-";
                labelGenerations.Text = "-";
                labelPopulationSize.Text = "-";
                labelDiversity.Text = "-";

                // Reset global values of the optimization process
                Program.ResetProgramValues();
                Program.StopEvolution = false;
                Program.EvolutionReady = false;
                Program.DraftApproximation.Reset();
                Program.ControlPoints = new List<Point>();
                drawPanel.Invalidate();

                // Get values chosen by the user in the UI
                int curveDegree = Decimal.ToInt32( nupCurveDegree.Value );
                int cps = Decimal.ToInt32( nupControlPoints.Value );
                int generations = Decimal.ToInt32( nupGenerations.Value );
                int iterations = Decimal.ToInt32( nupIterations.Value );
                bool adaptive = checkBoxAdaptive.Checked;

                // Start the thread
                this.evolutionThread = new Thread( () => startSolver( cps, curveDegree, generations, adaptive, iterations ) );
                this.evolutionThread.Start();
            }
            else {
                try {
                    this.evolutionThread.Abort();
                }
                catch (Exception ex) {
                    Console.WriteLine( "Stop button pressed: Exception while aborting main evolution thread!\n"+ex.Message );
                }
                evolutionStoped();
            }
            
        }
        //==============================================================



        //==============================================================
        public void startSolver( int cps, int curveDegree, int generations, bool adaptive, int iterations ) {
            List<Point> objective = new List<Point>();
            Point aux = new Point();
            lock (dummyContour) {
                foreach (PointF pt in Program.DraftOriginal.PathPoints) {
                    aux.X = Convert.ToInt32( pt.X );
                    aux.Y = Convert.ToInt32( pt.Y );
                    objective.Add( aux );
                }
            }

            for (int it = 1; it <= iterations; it++) {
                Console.WriteLine( "Iteration " + it );
                Heuristics.DifferentialEvolution de = new Heuristics.DifferentialEvolution( objective, cps, curveDegree, adaptive, generations );
                Console.WriteLine( "" );
                Program.ResetProgramValues();
            }
            evolutionStoped();
        }
        //==============================================================


        //==============================================================
        /// <summary>
        /// Called when an evolutionary process ends
        /// </summary>
        public void evolutionStoped() {
            Program.StopEvolution = true;
            buttonStart.Invoke( (MethodInvoker) delegate { buttonStart.Text = "Start"; } );
            Program.DraftRandomSolution.Reset();
            Program.RandomControlPoints.Clear();
            Program.EvolutionReady = true;
            drawPanel.Invalidate();
        }
        //==============================================================




        //==============================================================
        /// <summary>
        /// Changes the elements linked to the best solution found
        /// </summary>
        public void bestSolutionUpdated() {
            labelBestFitness.Invoke( (MethodInvoker) delegate { labelBestFitness.Text = Math.Round( Program.BestFitness, 3 ).ToString(); } );
            labelMSD.Invoke( (MethodInvoker) delegate { labelMSD.Text = Math.Round( Program.BestMSD, 3 ).ToString(); } );
            labelMaximalError.Invoke( (MethodInvoker) delegate { labelMaximalError.Text = Math.Round( Program.BestMaximalError, 3 ).ToString(); } );
            drawPanel.Invalidate();
        }
        //==============================================================



        //==============================================================
        /// <summary>
        /// Changes the elements linked to the best solution found
        /// </summary>
        public void generationChanged() {
            labelGenerations.Invoke( (MethodInvoker) delegate { labelGenerations.Text = Program.CurrentGeneration.ToString(); } );
            labelPopulationSize.Invoke( (MethodInvoker) delegate { labelPopulationSize.Text = Program.CurrentPopulationSize.ToString(); } );
            labelDiversity.Invoke( (MethodInvoker) delegate { labelDiversity.Text = Math.Round(Program.CurrentDiversity , 4 ).ToString(); } );

            if (Program.CurrentGeneration % 5 == 0 && (checkBoxRandomDraft.Checked || checkBoxRandomControlPoints.Checked) )
                drawPanel.Invalidate();
        }
        //==============================================================





        //==============================================================
        /// <summary>
        /// Called when this form has been closed
        /// </summary>
        private void OnFormClosed( object sender, FormClosedEventArgs e ) {
            Program.ResetProgramValues();
            Program.SolverToMainWindow( false );
        }
        //==============================================================





        //==============================================================
        private void OnOriginalDraftViewChanged(object sender, EventArgs e) {
            drawPanel.Invalidate();
        }
        //==============================================================
        private void OnApproximationDraftViewChanged(object sender, EventArgs e) {
            drawPanel.Invalidate();
        }
        //==============================================================
        private void OnRandomDraftViewChanged(object sender, EventArgs e) {
            drawPanel.Invalidate();
        }
        //==============================================================
        private void OnApproximationControlPointsViewChanged(object sender, EventArgs e) {
            drawPanel.Invalidate();
        }
        //==============================================================
        private void OnRandomControlPointsViewChanged(object sender, EventArgs e) {
            drawPanel.Invalidate();
        }
        //==============================================================



        //==============================================================
        /// <summary>
        /// When changing the curve degree some constraints over the # of control points should be granted
        /// </summary>
        private void OnChangeDegree(object sender, EventArgs e) {
            nupControlPoints.Value = Math.Max( nupControlPoints.Value, nupCurveDegree.Value + 1 );
        }
        //==============================================================
        /// <summary>
        /// When changing the # control points some constraints over the curve degree value should be granted
        /// </summary>
        private void OnControlPointsChange(object sender, EventArgs e) {
            nupCurveDegree.Value = Math.Min( nupControlPoints.Value-1 , nupCurveDegree.Value );
        }
        //==============================================================
        private void OnZoomLevelChanged(object sender, EventArgs e) {
            this.zoom = trackBarZoom.Value / 100f;
            Size size = new Size( Convert.ToInt32( drawPanelSize.Width * zoom), Convert.ToInt32( drawPanelSize.Height * zoom) );
            this.drawPanel.Size = size;
            this.drawPanel.Invalidate();
        }
        //==============================================================
    }

}
