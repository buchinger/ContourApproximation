﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MOG.Curves {
    
    /// <summary>
    /// Bèzier Curve is defined by several control points (minimum: three).
    /// The curve degree is (# control points - 1).
    /// </summary>
    public class Bezier : ICurve {

        /// <summary>
        /// Stores all bernstein polynomials already calculated
        /// </summary>
        private static Dictionary<Vec3, double> bernstein_calculated = new Dictionary<Vec3, double>(new MyComparer());
        private List<Vec3> control_points;
        private Dictionary<double, Vec3> curve_points = new Dictionary<double, Vec3>();




        /// <summary>
        /// Initialize a Beizer curve with a list of control points (3D)
        /// </summary>
        /// <param name="cps">The list of control points.</param>
        public Bezier(List<Vec3> cps) {
            control_points = new List<Vec3>(cps);
        }



        /// <summary>
        /// Initialize a Beizer curve with a list of points
        /// </summary>
        /// <param name="cps">The list of control points.</param>
        public Bezier(List<Point<int>> points) {
            control_points = new List<Vec3>();
            foreach (Point<int> p in points)
                control_points.Add(new Vec3(p.x, p.y, 0));
        }



        /// <summary>
        /// Required for the SortedDictionary used for Dynamic Programmin
        /// </summary>
        private class MyComparer : IEqualityComparer<Vec3> {
            public bool Equals(Vec3 a, Vec3 b) {
                return a.x == b.x && a.y == b.y && a.z == b.z;
            }
            public int GetHashCode(Vec3 obj) {
                return ("" + obj.x + "-" + obj.y + "-" + obj.z).GetHashCode();
            }
        }



        /// <summary>
        /// Returns the points of this curve at a given parameter between [0,1]
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public Vec3 getPointAt(double t) {
            // First check if the curve point was already calculated
            if (curve_points.ContainsKey(t))
                return curve_points[t];

            // If the curve point was not already calculated, we calculate it and store the result for future use
            int n = control_points.Count;
            int degree = n - 1;
            Vec3 res = new Vec3();
            Vec3 param = new Vec3(degree, 0, t);
            double bernstein;

            for (int i = 0; i < n; i++) {
                param.y = i;
                if (bernstein_calculated.ContainsKey(param)) { // Dynamic Programing =)
                    bernstein = bernstein_calculated[param];
                }
                else {
                    bernstein = Mathematic.bernsteinPolynomial(degree, i, t);
                    bernstein_calculated.Add(param, bernstein);
                    // Console.WriteLine("Bernstein: " + degree + " " + i + " " + t + " => " + bernstein);
                }

                // Console.WriteLine("cp(" + t + ") = " + control_points[i].x + " - " + control_points[i].y);
                res = res + (control_points[i] * bernstein);
                // Console.WriteLine("res(" + t + ") = " + res.x + " - " + res.y);
            }

            curve_points.Add(t, res);
            return res;
        }




        public int getSize() {
            return control_points.Count();
        }




        /// <summary>
        /// Returns the coordinates of a given control point
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Vec3 getControlPoint(int index) {
            if( index<0 || index>=control_points.Count() ) return new Vec3(-1,-1,-1);
            return control_points[index];
        }


        /// <summary>
        /// Return the list of control points from this bezier curve.
        /// </summary>
        /// <returns></returns>
        public List<Vec3> getControlPoints() {
            List<Vec3> list = new List<Vec3>(control_points);
            return list;
        }




        public int hasControlPointIn(int x, int y, int z = 0) {
            for (int i = 0; i < control_points.Count(); i++)
                if (Math.Abs(x - control_points[i].x) <= 2 && Math.Abs(y - control_points[i].y) <= 2)
                    return i;
            return -1;
        }




        public void moveControlPoint(int index, int x, int y) {
            control_points[index].x = x;
            control_points[index].y = y;
            curve_points.Clear();
        }



        public void translate(int x, int y) {
            foreach(Vec3 p in control_points ){
                p.x += x;
                p.y += y;
            }
            curve_points.Clear();
        }


        public void adjustC1(Vec3 tangent) { return; }
        public void adjustC2(Vec3 acceleration) { return; }
        public Vec3 getFirstDerivative(int u) { return null; }
        public Vec3 getSecondDerivative(int u) { return null; }

    }
}
